import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { PaperDB } from '@/services/database';
import type { ModelPaper, Question, AnswerKey, MarkingScheme } from '@/types';
import { toast } from 'sonner';
import { 
  ArrowLeft, 
  Plus, 
  Trash2,
  Save,
  Video,
  FileText,
  Clock,
  AlertCircle
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const TeacherUploadPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { currentUser } = useAuth();
  const editId = searchParams.get('edit');
  const defaultType = searchParams.get('type') || 'paper';
  
  const [activeTab, setActiveTab] = useState(defaultType);
  const [isLoading, setIsLoading] = useState(false);
  
  // Paper Form State
  const [paperForm, setPaperForm] = useState({
    title: '',
    description: '',
    subject: '',
    duration: 60,
    totalMarks: 100,
  });
  
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answerKey, setAnswerKey] = useState<AnswerKey>({});
  const [markingScheme, setMarkingScheme] = useState<MarkingScheme>({});
  
  // Recording Form State
  const [recordingForm, setRecordingForm] = useState({
    paperId: '',
    recordingUrl: '',
  });
  
  const [papers, setPapers] = useState<ModelPaper[]>([]);

  useEffect(() => {
    const allPapers = PaperDB.getAll();
    setPapers(allPapers);
    
    if (editId) {
      const paper = PaperDB.getById(editId);
      if (paper) {
        setPaperForm({
          title: paper.title,
          description: paper.description,
          subject: paper.subject,
          duration: paper.duration,
          totalMarks: paper.totalMarks,
        });
        setQuestions(paper.questions);
        setAnswerKey(paper.answerKey);
        setMarkingScheme(paper.markingScheme);
      }
    }
  }, [editId]);

  const addQuestion = () => {
    const newQuestion: Question = {
      id: `q${Date.now()}`,
      type: 'mcq',
      question: '',
      options: ['', '', '', ''],
      marks: 1,
    };
    setQuestions([...questions, newQuestion]);
  };

  const updateQuestion = (index: number, updates: Partial<Question>) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], ...updates };
    setQuestions(updated);
  };

  const removeQuestion = (index: number) => {
    const question = questions[index];
    setQuestions(questions.filter((_, i) => i !== index));
    
    // Also remove from answer key and marking scheme
    const newAnswerKey = { ...answerKey };
    delete newAnswerKey[question.id];
    setAnswerKey(newAnswerKey);
    
    const newMarkingScheme = { ...markingScheme };
    delete newMarkingScheme[question.id];
    setMarkingScheme(newMarkingScheme);
  };

  const updateAnswerKey = (questionId: string, answer: string | string[]) => {
    setAnswerKey({ ...answerKey, [questionId]: answer });
  };

  const updateMarkingScheme = (questionId: string, scheme: MarkingScheme[string]) => {
    setMarkingScheme({ ...markingScheme, [questionId]: scheme });
  };

  const handleSavePaper = async () => {
    if (!currentUser) return;
    
    // Validation
    if (!paperForm.title || !paperForm.subject) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    if (questions.length === 0) {
      toast.error('Please add at least one question');
      return;
    }
    
    // Check if all questions have answers
    const unanswered = questions.filter(q => !answerKey[q.id]);
    if (unanswered.length > 0) {
      toast.error(`Please provide answers for all questions (${unanswered.length} missing)`);
      return;
    }

    setIsLoading(true);

    try {
      const paperData = {
        ...paperForm,
        questions,
        answerKey,
        markingScheme,
        teacherId: currentUser.id,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 1 month
        isActive: true,
      };

      if (editId) {
        PaperDB.update(editId, paperData);
        toast.success('Paper updated successfully!');
      } else {
        PaperDB.create(paperData);
        toast.success('Paper created successfully!');
      }
      
      navigate('/teacher/papers');
    } catch (error) {
      toast.error('Failed to save paper');
    }
    
    setIsLoading(false);
  };

  const handleAddRecording = () => {
    if (!recordingForm.paperId || !recordingForm.recordingUrl) {
      toast.error('Please select a paper and enter a recording URL');
      return;
    }

    const paper = PaperDB.getById(recordingForm.paperId);
    if (!paper) {
      toast.error('Paper not found');
      return;
    }

    PaperDB.update(recordingForm.paperId, { zoomRecording: recordingForm.recordingUrl });
    toast.success('Recording added successfully!');
    navigate('/teacher');
  };

  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      toast.success(`PDF "${file.name}" uploaded successfully`);
      // In a real app, you would upload this to a server
    } else {
      toast.error('Please upload a valid PDF file');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-sky-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/teacher">
              <Button variant="ghost" className="text-gray-600 hover:text-orange-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">
              {editId ? 'Edit Paper' : 'Upload Resources'}
            </h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="paper" className="data-[state=active]:bg-sky-500 data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" />
              Model Paper
            </TabsTrigger>
            <TabsTrigger value="recording" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
              <Video className="w-4 h-4 mr-2" />
              Zoom Recording
            </TabsTrigger>
          </TabsList>

          <TabsContent value="paper">
            <Card>
              <CardHeader>
                <CardTitle>{editId ? 'Edit Model Paper' : 'Create New Model Paper'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Paper Details */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Paper Title *</Label>
                    <Input
                      id="title"
                      value={paperForm.title}
                      onChange={(e) => setPaperForm({ ...paperForm, title: e.target.value })}
                      placeholder="e.g., Mathematics Model Paper 1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      value={paperForm.subject}
                      onChange={(e) => setPaperForm({ ...paperForm, subject: e.target.value })}
                      placeholder="e.g., Mathematics"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={paperForm.description}
                    onChange={(e) => setPaperForm({ ...paperForm, description: e.target.value })}
                    placeholder="Brief description of the paper..."
                    rows={2}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration (minutes) *</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={paperForm.duration}
                      onChange={(e) => setPaperForm({ ...paperForm, duration: parseInt(e.target.value) || 60 })}
                      min={1}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="totalMarks">Total Marks *</Label>
                    <Input
                      id="totalMarks"
                      type="number"
                      value={paperForm.totalMarks}
                      onChange={(e) => setPaperForm({ ...paperForm, totalMarks: parseInt(e.target.value) || 100 })}
                      min={1}
                    />
                  </div>
                </div>

                {/* PDF Upload */}
                <div className="bg-sky-50 rounded-lg p-4">
                  <Label className="flex items-center text-sky-700 mb-2">
                    <FileText className="w-4 h-4 mr-2" />
                    Upload PDF (Optional)
                  </Label>
                  <Input
                    type="file"
                    accept=".pdf"
                    onChange={handlePdfUpload}
                    className="bg-white"
                  />
                  <p className="text-xs text-sky-600 mt-1">
                    Upload the complete question paper as PDF
                  </p>
                </div>

                {/* Questions */}
                <div className="border-t border-gray-200 pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">Questions ({questions.length})</h3>
                    <Button onClick={addQuestion} variant="outline" className="border-sky-500 text-sky-600">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Question
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <Card key={question.id} className="border-gray-200">
                        <CardContent className="p-4 space-y-4">
                          <div className="flex items-start justify-between">
                            <span className="font-medium text-gray-700">Question {index + 1}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeQuestion(index)}
                              className="text-red-500 hover:text-red-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>

                          <div className="space-y-2">
                            <Label>Question Text</Label>
                            <Textarea
                              value={question.question}
                              onChange={(e) => updateQuestion(index, { question: e.target.value })}
                              placeholder="Enter question..."
                              rows={2}
                            />
                          </div>

                          <div className="grid md:grid-cols-3 gap-4">
                            <div>
                              <Label>Type</Label>
                              <Select
                                value={question.type}
                                onValueChange={(value: 'mcq' | 'essay' | 'short_answer') => 
                                  updateQuestion(index, { type: value })
                                }
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="mcq">Multiple Choice</SelectItem>
                                  <SelectItem value="short_answer">Short Answer</SelectItem>
                                  <SelectItem value="essay">Essay</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label>Marks</Label>
                              <Input
                                type="number"
                                value={question.marks}
                                onChange={(e) => updateQuestion(index, { marks: parseInt(e.target.value) || 1 })}
                                min={1}
                              />
                            </div>
                            <div>
                              <Label>Correct Answer</Label>
                              {question.type === 'mcq' ? (
                                <Input
                                  placeholder="Enter correct option"
                                  value={(answerKey[question.id] as string) || ''}
                                  onChange={(e) => updateAnswerKey(question.id, e.target.value)}
                                />
                              ) : (
                                <Input
                                  placeholder="Enter answer key"
                                  value={(answerKey[question.id] as string) || ''}
                                  onChange={(e) => updateAnswerKey(question.id, e.target.value)}
                                />
                              )}
                            </div>
                          </div>

                          {question.type === 'mcq' && (
                            <div className="space-y-2">
                              <Label>Options</Label>
                              {question.options?.map((option, optIndex) => (
                                <Input
                                  key={optIndex}
                                  value={option}
                                  onChange={(e) => {
                                    const newOptions = [...(question.options || [])];
                                    newOptions[optIndex] = e.target.value;
                                    updateQuestion(index, { options: newOptions });
                                  }}
                                  placeholder={`Option ${optIndex + 1}`}
                                />
                              ))}
                            </div>
                          )}

                          <div className="space-y-2">
                            <Label>Explanation (Optional)</Label>
                            <Textarea
                              value={markingScheme[question.id]?.explanation || ''}
                              onChange={(e) => updateMarkingScheme(question.id, {
                                correctAnswer: answerKey[question.id] || '',
                                marks: question.marks,
                                explanation: e.target.value,
                              })}
                              placeholder="Explain the correct answer..."
                              rows={2}
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {questions.length === 0 && (
                    <div className="text-center py-8 bg-gray-50 rounded-lg">
                      <AlertCircle className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">No questions added yet</p>
                      <Button onClick={addQuestion} variant="outline" className="mt-2">
                        <Plus className="w-4 h-4 mr-2" />
                        Add First Question
                      </Button>
                    </div>
                  )}
                </div>

                {/* Save Button */}
                <div className="flex justify-end gap-4 pt-4 border-t border-gray-200">
                  <Link to="/teacher/papers">
                    <Button variant="outline">Cancel</Button>
                  </Link>
                  <Button 
                    onClick={handleSavePaper} 
                    disabled={isLoading}
                    className="bg-sky-500 hover:bg-sky-600"
                  >
                    {isLoading ? (
                      <>
                        <Clock className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        {editId ? 'Update Paper' : 'Save Paper'}
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recording">
            <Card>
              <CardHeader>
                <CardTitle>Add Zoom Recording</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Select Paper *</Label>
                  <Select
                    value={recordingForm.paperId}
                    onValueChange={(value) => setRecordingForm({ ...recordingForm, paperId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a paper..." />
                    </SelectTrigger>
                    <SelectContent>
                      {papers.map((paper) => (
                        <SelectItem key={paper.id} value={paper.id}>
                          {paper.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Recording URL *</Label>
                  <Input
                    value={recordingForm.recordingUrl}
                    onChange={(e) => setRecordingForm({ ...recordingForm, recordingUrl: e.target.value })}
                    placeholder="https://zoom.us/rec/..."
                  />
                  <p className="text-xs text-gray-500">
                    Paste the Zoom cloud recording link here
                  </p>
                </div>

                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="flex items-start">
                    <Video className="w-5 h-5 text-purple-600 mr-2 mt-0.5" />
                    <div>
                      <p className="text-sm text-purple-700 font-medium">Access Control</p>
                      <p className="text-sm text-purple-600">
                        Students will only be able to access this recording after they submit their answers 
                        or if they request special access.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-4">
                  <Link to="/teacher">
                    <Button variant="outline">Cancel</Button>
                  </Link>
                  <Button 
                    onClick={handleAddRecording}
                    className="bg-purple-500 hover:bg-purple-600"
                  >
                    <Video className="w-4 h-4 mr-2" />
                    Add Recording
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default TeacherUploadPage;
