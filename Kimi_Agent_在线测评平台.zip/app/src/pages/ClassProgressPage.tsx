import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PaperDB, AttemptDB, ClassAverageDB, StudentDB } from '@/services/database';
import type { ModelPaper, ExamAttempt, Student, ClassAverage } from '@/types';
import { 
  ArrowLeft, 
  TrendingUp, 
  Award,
  BarChart3,
  Download,
  AlertCircle,
  FileText
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';

const ClassProgressPage: React.FC = () => {
  const [papers, setPapers] = useState<ModelPaper[]>([]);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [classAverages, setClassAverages] = useState<ClassAverage[]>([]);
  const [selectedPaper, setSelectedPaper] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const allPapers = PaperDB.getAll();
    setPapers(allPapers);
    
    const allAttempts = AttemptDB.getAll();
    setAttempts(allAttempts);
    
    const allStudents = StudentDB.getAll();
    setStudents(allStudents);
    
    const averages = ClassAverageDB.getAll();
    setClassAverages(averages);
  };

  const getFilteredAttempts = () => {
    if (selectedPaper === 'all') {
      return attempts.filter(a => a.status === 'graded');
    }
    return attempts.filter(a => a.paperId === selectedPaper && a.status === 'graded');
  };

  const getGradeDistribution = () => {
    const filtered = getFilteredAttempts();
    const grades: { [key: string]: number } = { 'A+': 0, 'A': 0, 'B+': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0 };
    
    filtered.forEach(attempt => {
      if (attempt.grade) {
        grades[attempt.grade] = (grades[attempt.grade] || 0) + 1;
      }
    });
    
    return Object.entries(grades)
      .filter(([_, count]) => count > 0)
      .map(([grade, count]) => ({ grade, count }));
  };

  const getPerformanceByPaper = () => {
    return papers.map(paper => {
      const avg = classAverages.find(a => a.paperId === paper.id);
      const paperAttempts = attempts.filter(a => a.paperId === paper.id && a.status === 'graded');
      return {
        name: paper.title.length > 20 ? paper.title.substring(0, 20) + '...' : paper.title,
        fullName: paper.title,
        average: avg?.averageMarks || 0,
        highest: avg?.highestMarks || 0,
        lowest: avg?.lowestMarks || 0,
        submissions: paperAttempts.length,
      };
    });
  };

  const getStudentRankings = () => {
    const studentScores: { [key: string]: { total: number; count: number; name: string } } = {};
    
    attempts.filter(a => a.status === 'graded').forEach(attempt => {
      const student = students.find(s => s.id === attempt.studentId);
      if (student) {
        if (!studentScores[student.id]) {
          studentScores[student.id] = { total: 0, count: 0, name: student.name };
        }
        studentScores[student.id].total += attempt.percentage || 0;
        studentScores[student.id].count += 1;
      }
    });

    return Object.entries(studentScores)
      .map(([id, data]) => ({
        id,
        name: data.name,
        average: Math.round(data.total / data.count),
        papers: data.count,
      }))
      .sort((a, b) => b.average - a.average)
      .slice(0, 10);
  };

  const getOverallStats = () => {
    const filtered = getFilteredAttempts();
    const percentages = filtered.map(a => a.percentage || 0);
    
    return {
      totalStudents: students.length,
      totalSubmissions: filtered.length,
      averageScore: percentages.length > 0 ? Math.round(percentages.reduce((a, b) => a + b, 0) / percentages.length) : 0,
      highestScore: percentages.length > 0 ? Math.max(...percentages) : 0,
      lowestScore: percentages.length > 0 ? Math.min(...percentages) : 0,
      passRate: percentages.length > 0 
        ? Math.round((percentages.filter(p => p >= 40).length / percentages.length) * 100) 
        : 0,
    };
  };

  const gradeColors: { [key: string]: string } = {
    'A+': '#10b981',
    'A': '#34d399',
    'B+': '#3b82f6',
    'B': '#60a5fa',
    'C': '#f59e0b',
    'D': '#f97316',
    'F': '#ef4444',
  };

  const stats = getOverallStats();
  const gradeDistribution = getGradeDistribution();
  const performanceByPaper = getPerformanceByPaper();
  const studentRankings = getStudentRankings();

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-sky-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/teacher">
              <Button variant="ghost" className="text-gray-600 hover:text-orange-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">Class Progress Report</h1>
            <Button variant="outline" size="sm" onClick={() => alert('Export feature coming soon!')}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Paper Filter */}
        <div className="mb-8">
          <Select value={selectedPaper} onValueChange={setSelectedPaper}>
            <SelectTrigger className="w-full md:w-80">
              <SelectValue placeholder="Filter by paper..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Papers</SelectItem>
              {papers.map(paper => (
                <SelectItem key={paper.id} value={paper.id}>{paper.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-sky-500 to-sky-600 text-white border-0">
            <CardContent className="p-4">
              <p className="text-sky-100 text-xs mb-1">Total Students</p>
              <p className="text-2xl font-bold">{stats.totalStudents}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-gray-500 text-xs mb-1">Submissions</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalSubmissions}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-gray-500 text-xs mb-1">Class Average</p>
              <p className="text-2xl font-bold text-sky-600">{stats.averageScore}%</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-gray-500 text-xs mb-1">Highest</p>
              <p className="text-2xl font-bold text-emerald-600">{stats.highestScore}%</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-gray-500 text-xs mb-1">Lowest</p>
              <p className="text-2xl font-bold text-orange-600">{stats.lowestScore}%</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-gray-500 text-xs mb-1">Pass Rate</p>
              <p className="text-2xl font-bold text-purple-600">{stats.passRate}%</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Grade Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <Award className="w-5 h-5 mr-2 text-orange-500" />
                Grade Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              {gradeDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={gradeDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ grade, count }) => `${grade}: ${count}`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {gradeDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={gradeColors[entry.grade] || '#8884d8'} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center">
                  <p className="text-gray-500">No data available</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Performance by Paper */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <BarChart3 className="w-5 h-5 mr-2 text-sky-600" />
                Performance by Paper
              </CardTitle>
            </CardHeader>
            <CardContent>
              {performanceByPaper.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={performanceByPaper}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" domain={[0, 100]} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }}
                      formatter={(value: number) => [`${value}%`, '']}
                    />
                    <Legend />
                    <Bar dataKey="average" name="Class Average" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="highest" name="Highest" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center">
                  <p className="text-gray-500">No data available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Student Rankings */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <TrendingUp className="w-5 h-5 mr-2 text-emerald-500" />
              Top Performing Students
            </CardTitle>
          </CardHeader>
          <CardContent>
            {studentRankings.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Rank</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Student</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Papers</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Average</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Progress</th>
                    </tr>
                  </thead>
                  <tbody>
                    {studentRankings.map((student, index) => (
                      <tr key={student.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4">
                          {index < 3 ? (
                            <Badge className={`
                              ${index === 0 ? 'bg-yellow-100 text-yellow-700' : ''}
                              ${index === 1 ? 'bg-gray-100 text-gray-700' : ''}
                              ${index === 2 ? 'bg-orange-100 text-orange-700' : ''}
                            `}>
                              #{index + 1}
                            </Badge>
                          ) : (
                            <span className="text-gray-500">#{index + 1}</span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-medium text-gray-900">{student.name}</td>
                        <td className="py-3 px-4 text-gray-600">{student.papers}</td>
                        <td className="py-3 px-4">
                          <span className={`font-medium ${
                            student.average >= 60 ? 'text-emerald-600' : 'text-orange-600'
                          }`}>
                            {student.average}%
                          </span>
                        </td>
                        <td className="py-3 px-4 w-48">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${
                                  student.average >= 80 ? 'bg-emerald-500' :
                                  student.average >= 60 ? 'bg-sky-500' : 'bg-orange-500'
                                }`}
                                style={{ width: `${student.average}%` }}
                              />
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No student data available yet.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Paper Statistics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <FileText className="w-5 h-5 mr-2 text-purple-500" />
              Paper Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            {papers.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Paper</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Submissions</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Average</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Highest</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Lowest</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {papers.map((paper) => {
                      const avg = classAverages.find(a => a.paperId === paper.id);
                      const paperAttempts = attempts.filter(a => a.paperId === paper.id && a.status === 'graded');
                      return (
                        <tr key={paper.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-3 px-4">
                            <div>
                              <p className="font-medium text-gray-900">{paper.title}</p>
                              <p className="text-xs text-gray-500">{paper.subject}</p>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-gray-600">{paperAttempts.length}</td>
                          <td className="py-3 px-4">
                            <span className="font-medium text-sky-600">
                              {avg ? Math.round(avg.averageMarks) : 0}%
                            </span>
                          </td>
                          <td className="py-3 px-4 text-emerald-600">{avg?.highestMarks || 0}%</td>
                          <td className="py-3 px-4 text-orange-600">{avg?.lowestMarks || 0}%</td>
                          <td className="py-3 px-4">
                            <Badge className={paper.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'}>
                              {paper.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No papers available.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ClassProgressPage;
