import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { PaperDB, AttemptDB, ClassAverageDB } from '@/services/database';
import type { ModelPaper, ExamAttempt, ClassAverage } from '@/types';
import { toast } from 'sonner';
import { 
  GraduationCap, 
  BookOpen, 
  Clock, 
  TrendingUp, 
  Award, 
  PlayCircle,
  LogOut,
  FileText,
  MessageCircle,
  BarChart3,
  ChevronRight,
  Calendar,
  AlertCircle
} from 'lucide-react';

const StudentDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const [papers, setPapers] = useState<ModelPaper[]>([]);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [averages, setAverages] = useState<ClassAverage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setIsLoading(true);
    // Load active papers
    const activePapers = PaperDB.getActive();
    setPapers(activePapers);
    
    // Load student's attempts
    if (currentUser?.id) {
      const studentAttempts = AttemptDB.getByStudent(currentUser.id);
      setAttempts(studentAttempts);
    }
    
    // Load class averages
    const allAverages = ClassAverageDB.getAll();
    setAverages(allAverages);
    
    setIsLoading(false);
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigate('/');
  };

  const getAttemptForPaper = (paperId: string) => {
    return attempts.find(a => a.paperId === paperId);
  };

  const getPaperStatus = (paper: ModelPaper) => {
    const attempt = getAttemptForPaper(paper.id);
    if (!attempt) return 'available';
    return attempt.status;
  };

  const calculateOverallProgress = () => {
    if (attempts.length === 0) return 0;
    const completed = attempts.filter(a => a.status === 'graded').length;
    return Math.round((completed / attempts.length) * 100);
  };

  const getAverageScore = () => {
    const graded = attempts.filter(a => a.status === 'graded');
    if (graded.length === 0) return 0;
    return Math.round(graded.reduce((acc, a) => acc + (a.percentage || 0), 0) / graded.length);
  };

  const student = currentUser as any;

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-sky-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-sky-600 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-sky-600 to-orange-500 bg-clip-text text-transparent">
                EduExam Portal
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 text-sm text-gray-600">
                <span className="font-medium">{student?.name}</span>
                <span className="text-gray-400">|</span>
                <span className="text-sky-600">{student?.adminNo}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-gray-600 hover:text-red-600">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, <span className="text-sky-600">{student?.name?.split(' ')[0]}</span>!
          </h1>
          <p className="text-gray-600">
            Here's your exam preparation dashboard. Keep up the great work!
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-sky-500 to-sky-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sky-100 text-sm">Available Papers</p>
                  <p className="text-3xl font-bold">{papers.length}</p>
                </div>
                <BookOpen className="w-10 h-10 text-sky-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">Completed</p>
                  <p className="text-3xl font-bold">{attempts.filter(a => a.status === 'graded').length}</p>
                </div>
                <Award className="w-10 h-10 text-orange-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm">Average Score</p>
                  <p className="text-3xl font-bold">{getAverageScore()}%</p>
                </div>
                <TrendingUp className="w-10 h-10 text-emerald-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Progress</p>
                  <p className="text-3xl font-bold">{calculateOverallProgress()}%</p>
                </div>
                <BarChart3 className="w-10 h-10 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Available Papers */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <BookOpen className="w-5 h-5 mr-2 text-sky-600" />
                Available Model Papers
              </h2>
              <Badge variant="outline" className="bg-sky-50 text-sky-700 border-sky-200">
                One Week Access
              </Badge>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600"></div>
              </div>
            ) : papers.length === 0 ? (
              <Card className="bg-gray-50 border-gray-100">
                <CardContent className="p-12 text-center">
                  <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No active papers available at the moment.</p>
                  <p className="text-gray-400 text-sm mt-1">Check back later for new papers!</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {papers.map((paper) => {
                  const status = getPaperStatus(paper);
                  const attempt = getAttemptForPaper(paper.id);
                  
                  return (
                    <Card key={paper.id} className="hover:shadow-lg transition-shadow border-gray-100">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-semibold text-gray-900">{paper.title}</h3>
                              {status === 'graded' && (
                                <Badge className="bg-emerald-100 text-emerald-700">
                                  Completed
                                </Badge>
                              )}
                              {status === 'in_progress' && (
                                <Badge className="bg-amber-100 text-amber-700">
                                  In Progress
                                </Badge>
                              )}
                              {status === 'submitted' && (
                                <Badge className="bg-blue-100 text-blue-700">
                                  Submitted
                                </Badge>
                              )}
                              {status === 'available' && (
                                <Badge className="bg-sky-100 text-sky-700">
                                  Available
                                </Badge>
                              )}
                            </div>
                            <p className="text-gray-600 text-sm mb-3">{paper.description}</p>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <span className="flex items-center">
                                <Clock className="w-4 h-4 mr-1" />
                                {paper.duration} minutes
                              </span>
                              <span className="flex items-center">
                                <Award className="w-4 h-4 mr-1" />
                                {paper.totalMarks} marks
                              </span>
                              <span className="flex items-center">
                                <FileText className="w-4 h-4 mr-1" />
                                {paper.questions.length} questions
                              </span>
                              <span className="flex items-center">
                                <Calendar className="w-4 h-4 mr-1" />
                                Expires: {new Date(paper.expiresAt).toLocaleDateString()}
                              </span>
                            </div>
                            {attempt?.marks !== undefined && (
                              <div className="mt-3 flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                  <span className="text-sm text-gray-600">Your Score:</span>
                                  <span className="font-semibold text-emerald-600">
                                    {attempt.marks}/{paper.totalMarks}
                                  </span>
                                  <span className="text-sm text-gray-500">
                                    ({attempt.percentage}%)
                                  </span>
                                </div>
                                <Progress 
                                  value={attempt.percentage} 
                                  className="w-24 h-2"
                                />
                              </div>
                            )}
                          </div>
                          <div className="ml-4">
                            {status === 'available' && (
                              <Link to={`/exam/${paper.id}`}>
                                <Button className="bg-sky-500 hover:bg-sky-600">
                                  Start Exam
                                  <ChevronRight className="w-4 h-4 ml-1" />
                                </Button>
                              </Link>
                            )}
                            {status === 'in_progress' && (
                              <Link to={`/exam/${paper.id}`}>
                                <Button className="bg-amber-500 hover:bg-amber-600">
                                  Continue
                                  <ChevronRight className="w-4 h-4 ml-1" />
                                </Button>
                              </Link>
                            )}
                            {status === 'graded' && (
                              <div className="flex flex-col gap-2">
                                <Link to={`/results/${attempt?.id}`}>
                                  <Button variant="outline" className="border-emerald-500 text-emerald-600 hover:bg-emerald-50">
                                    View Results
                                  </Button>
                                </Link>
                                <Link to={`/chat/${paper.id}`}>
                                  <Button variant="outline" size="sm" className="border-sky-500 text-sky-600 hover:bg-sky-50">
                                    <MessageCircle className="w-4 h-4 mr-1" />
                                    Ask AI
                                  </Button>
                                </Link>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="border-gray-100">
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to="/progress">
                  <Button variant="outline" className="w-full justify-start border-gray-200 hover:border-sky-300 hover:bg-sky-50">
                    <BarChart3 className="w-4 h-4 mr-2 text-sky-600" />
                    View Progress Report
                  </Button>
                </Link>
                <Link to="/recordings">
                  <Button variant="outline" className="w-full justify-start border-gray-200 hover:border-orange-300 hover:bg-orange-50">
                    <PlayCircle className="w-4 h-4 mr-2 text-orange-600" />
                    Zoom Recordings
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Class Averages */}
            <Card className="border-gray-100">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-orange-500" />
                  Class Averages
                </CardTitle>
              </CardHeader>
              <CardContent>
                {averages.length === 0 ? (
                  <p className="text-gray-500 text-sm text-center py-4">
                    No class data available yet.
                  </p>
                ) : (
                  <div className="space-y-4">
                    {averages.slice(0, 5).map((avg) => (
                      <div key={avg.paperId} className="border-b border-gray-100 last:border-0 pb-3 last:pb-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{avg.paperTitle}</p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-sm text-gray-500">Avg: {Math.round(avg.averageMarks)}%</span>
                          <span className="text-xs text-gray-400">{avg.totalStudents} students</span>
                        </div>
                        <Progress 
                          value={avg.averageMarks} 
                          className="w-full h-1.5 mt-2"
                        />
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="border-gray-100">
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {attempts.length === 0 ? (
                  <p className="text-gray-500 text-sm text-center py-4">
                    No activity yet. Start your first exam!
                  </p>
                ) : (
                  <div className="space-y-3">
                    {attempts.slice(-3).reverse().map((attempt) => {
                      const paper = papers.find(p => p.id === attempt.paperId);
                      return (
                        <div key={attempt.id} className="flex items-center gap-3 text-sm">
                          <div className={`w-2 h-2 rounded-full ${
                            attempt.status === 'graded' ? 'bg-emerald-500' : 
                            attempt.status === 'submitted' ? 'bg-blue-500' : 'bg-amber-500'
                          }`} />
                          <div className="flex-1">
                            <p className="text-gray-900 truncate">{paper?.title || 'Unknown Paper'}</p>
                            <p className="text-gray-400 text-xs">
                              {new Date(attempt.startedAt).toLocaleDateString()}
                            </p>
                          </div>
                          {attempt.percentage !== undefined && (
                            <span className={`font-medium ${
                              attempt.percentage >= 60 ? 'text-emerald-600' : 'text-orange-600'
                            }`}>
                              {attempt.percentage}%
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
