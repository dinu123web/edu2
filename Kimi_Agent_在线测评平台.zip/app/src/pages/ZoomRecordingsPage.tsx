import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { PaperDB, AttemptDB } from '@/services/database';
import type { ModelPaper, ExamAttempt } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { 
  ArrowLeft, 
  PlayCircle, 
  Lock, 
  Unlock,
  Search,
  Video,
  Clock,
  Calendar,
  FileText,
  MessageSquare
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const ZoomRecordingsPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [papers, setPapers] = useState<ModelPaper[]>([]);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPaper, setSelectedPaper] = useState<ModelPaper | null>(null);
  const [showRequestDialog, setShowRequestDialog] = useState(false);
  const [requestMessage, setRequestMessage] = useState('');

  useEffect(() => {
    if (!currentUser) return;
    
    const allPapers = PaperDB.getAll();
    const papersWithRecordings = allPapers.filter(p => p.zoomRecording);
    setPapers(papersWithRecordings);
    
    const studentAttempts = AttemptDB.getByStudent(currentUser.id);
    setAttempts(studentAttempts);
  }, [currentUser]);

  const hasAccessToRecording = (paper: ModelPaper): boolean => {
    const attempt = attempts.find(a => a.paperId === paper.id);
    // Access granted if: student has graded attempt OR has submitted answers
    return !!attempt && (attempt.status === 'graded' || attempt.status === 'submitted');
  };

  const getAttemptForPaper = (paperId: string) => {
    return attempts.find(a => a.paperId === paperId);
  };

  const handleRequestAccess = () => {
    if (!selectedPaper) return;
    
    // In a real app, this would send a request to the teacher
    // For demo, we'll just show a success message
    alert(`Access request sent for "${selectedPaper.title}". Your message: ${requestMessage}`);
    setShowRequestDialog(false);
    setRequestMessage('');
    setSelectedPaper(null);
  };

  const filteredPapers = papers.filter(paper => 
    paper.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    paper.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/dashboard">
              <Button variant="ghost" className="text-gray-600 hover:text-sky-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-lg font-semibold text-gray-900 flex items-center">
              <Video className="w-5 h-5 mr-2 text-sky-600" />
              Zoom Recordings
            </h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Info Card */}
        <Card className="mb-8 bg-gradient-to-r from-sky-50 to-orange-50 border-sky-100">
          <CardContent className="p-6">
            <div className="flex items-start">
              <div className="w-12 h-12 bg-sky-100 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                <PlayCircle className="w-6 h-6 text-sky-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-2">Access Zoom Recordings</h2>
                <p className="text-gray-600 text-sm">
                  Watch recorded sessions for papers you've completed. Recordings are available after you submit your answers. 
                  If you need early access, you can request it from your teacher.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Search recordings by paper title or subject..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 border-gray-200 focus:border-sky-500 focus:ring-sky-500"
          />
        </div>

        {/* Recordings List */}
        {filteredPapers.length === 0 ? (
          <Card className="bg-gray-50 border-gray-100">
            <CardContent className="p-12 text-center">
              <Video className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No recordings available yet.</p>
              <p className="text-gray-400 text-sm mt-1">
                Recordings will appear here once teachers upload them.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {filteredPapers.map((paper) => {
              const hasAccess = hasAccessToRecording(paper);
              const attempt = getAttemptForPaper(paper.id);
              
              return (
                <Card key={paper.id} className={`hover:shadow-lg transition-shadow ${!hasAccess ? 'opacity-75' : ''}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center mr-4 ${
                          hasAccess ? 'bg-sky-100' : 'bg-gray-100'
                        }`}>
                          {hasAccess ? (
                            <PlayCircle className="w-6 h-6 text-sky-600" />
                          ) : (
                            <Lock className="w-6 h-6 text-gray-400" />
                          )}
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{paper.title}</h3>
                          <p className="text-sm text-gray-500">{paper.subject}</p>
                        </div>
                      </div>
                      <Badge className={hasAccess ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}>
                        {hasAccess ? (
                          <span className="flex items-center">
                            <Unlock className="w-3 h-3 mr-1" />
                            Access Granted
                          </span>
                        ) : (
                          <span className="flex items-center">
                            <Lock className="w-3 h-3 mr-1" />
                            Locked
                          </span>
                        )}
                      </Badge>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                      <span className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(paper.createdAt).toLocaleDateString()}
                      </span>
                      <span className="flex items-center">
                        <FileText className="w-4 h-4 mr-1" />
                        {paper.questions.length} questions
                      </span>
                      {attempt && (
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {attempt.percentage}%
                        </span>
                      )}
                    </div>

                    {hasAccess ? (
                      <div className="space-y-3">
                        <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
                          <a 
                            href={paper.zoomRecording} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex flex-col items-center text-white hover:text-sky-300 transition-colors"
                          >
                            <PlayCircle className="w-16 h-16 mb-2" />
                            <span className="text-sm">Click to Watch Recording</span>
                          </a>
                        </div>
                        <a 
                          href={paper.zoomRecording} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="block"
                        >
                          <Button className="w-full bg-sky-500 hover:bg-sky-600">
                            <PlayCircle className="w-4 h-4 mr-2" />
                            Watch Recording
                          </Button>
                        </a>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                          <div className="text-center">
                            <Lock className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                            <p className="text-gray-500 text-sm">Complete the paper to unlock</p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          className="w-full border-orange-400 text-orange-600 hover:bg-orange-50"
                          onClick={() => {
                            setSelectedPaper(paper);
                            setShowRequestDialog(true);
                          }}
                        >
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Request Early Access
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Request Access Dialog */}
      <Dialog open={showRequestDialog} onOpenChange={setShowRequestDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request Early Access</DialogTitle>
            <DialogDescription>
              Send a request to your teacher for early access to the recording for "{selectedPaper?.title}".
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Message to Teacher (Optional)</label>
              <textarea
                value={requestMessage}
                onChange={(e) => setRequestMessage(e.target.value)}
                placeholder="Explain why you need early access..."
                className="w-full min-h-[100px] p-3 border border-gray-200 rounded-lg focus:border-sky-500 focus:ring-sky-500 resize-none"
              />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setShowRequestDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleRequestAccess} className="bg-sky-500 hover:bg-sky-600">
              Send Request
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ZoomRecordingsPage;
