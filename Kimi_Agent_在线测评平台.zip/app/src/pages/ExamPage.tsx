import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { PaperDB, AttemptDB, MarkingSystem, ClassAverageDB } from '@/services/database';
import type { ModelPaper, ExamAttempt, Question } from '@/types';
import { toast } from 'sonner';
import { 
  Clock, 
  AlertCircle, 
  ChevronLeft, 
  ChevronRight, 
  FileText,
  Save,
  Send
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const ExamPage: React.FC = () => {
  const { paperId } = useParams<{ paperId: string }>();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const [paper, setPaper] = useState<ModelPaper | null>(null);
  const [attempt, setAttempt] = useState<ExamAttempt | null>(null);
  const [answers, setAnswers] = useState<{ [key: string]: string | string[] }>({});
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showTimeWarning, setShowTimeWarning] = useState(false);

  // Initialize exam
  useEffect(() => {
    if (!paperId || !currentUser) return;
    
    const loadedPaper = PaperDB.getById(paperId);
    if (!loadedPaper) {
      toast.error('Paper not found');
      navigate('/dashboard');
      return;
    }
    
    setPaper(loadedPaper);
    
    // Check for existing attempt
    const existingAttempt = AttemptDB.getStudentPaperAttempt(currentUser.id, paperId);
    
    if (existingAttempt) {
      if (existingAttempt.status === 'graded' || existingAttempt.status === 'submitted') {
        toast.info('You have already completed this paper');
        navigate('/dashboard');
        return;
      }
      // Resume existing attempt
      setAttempt(existingAttempt);
      setAnswers(existingAttempt.answers || {});
      const elapsed = Math.floor((Date.now() - new Date(existingAttempt.startedAt).getTime()) / 1000);
      const remaining = Math.max(0, loadedPaper.duration * 60 - elapsed);
      setTimeLeft(remaining);
    } else {
      // Create new attempt
      const newAttempt = AttemptDB.create({
        studentId: currentUser.id,
        paperId: paperId,
        startedAt: new Date().toISOString(),
        answers: {},
        status: 'in_progress',
        timeSpent: 0,
      });
      setAttempt(newAttempt);
      setTimeLeft(loadedPaper.duration * 60);
    }
  }, [paperId, currentUser, navigate]);

  // Timer
  useEffect(() => {
    if (timeLeft <= 0 || !attempt) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 300 && prev > 299 && !showTimeWarning) {
          setShowTimeWarning(true);
          toast.warning('Only 5 minutes remaining!');
        }
        if (prev <= 1) {
          clearInterval(timer);
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, attempt, showTimeWarning]);

  // Save progress periodically
  useEffect(() => {
    if (!attempt) return;
    
    const saveInterval = setInterval(() => {
      AttemptDB.update(attempt.id, {
        answers,
        timeSpent: (paper?.duration || 0) * 60 - timeLeft,
      });
    }, 30000); // Save every 30 seconds

    return () => clearInterval(saveInterval);
  }, [attempt, answers, timeLeft, paper]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (questionId: string, answer: string | string[]) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const handleSaveProgress = () => {
    if (!attempt) return;
    AttemptDB.update(attempt.id, { answers });
    toast.success('Progress saved!');
  };

  const handleSubmit = async () => {
    if (!attempt || !paper) return;
    setIsSubmitting(true);

    // Calculate marks
    const result = MarkingSystem.calculateMarks({ ...attempt, answers }, paper);
    
    // Update attempt
    const updatedAttempt = AttemptDB.update(attempt.id, {
      answers,
      submittedAt: new Date().toISOString(),
      marks: result.marks,
      percentage: result.percentage,
      grade: result.grade,
      status: 'graded',
      timeSpent: (paper.duration * 60) - timeLeft,
    });

    // Update class average
    const classAvg = AttemptDB.calculateClassAverage(paper.id);
    ClassAverageDB.save(classAvg);

    if (updatedAttempt) {
      toast.success(`Exam submitted! You scored ${result.percentage}%`);
      navigate(`/results/${attempt.id}`);
    }
    setIsSubmitting(false);
  };

  const handleAutoSubmit = () => {
    toast.warning('Time is up! Your exam is being submitted automatically.');
    handleSubmit();
  };

  const renderQuestion = (question: Question) => {
    const answer = answers[question.id];

    switch (question.type) {
      case 'mcq':
        return (
          <RadioGroup
            value={answer as string}
            onValueChange={(value) => handleAnswerChange(question.id, value)}
            className="space-y-3"
          >
            {question.options?.map((option, idx) => (
              <div key={idx} className="flex items-center space-x-3 p-3 rounded-lg border border-gray-200 hover:bg-sky-50 transition-colors">
                <RadioGroupItem value={option} id={`${question.id}-${idx}`} />
                <Label htmlFor={`${question.id}-${idx}`} className="flex-1 cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        );

      case 'short_answer':
        return (
          <Textarea
            value={(answer as string) || ''}
            onChange={(e) => handleAnswerChange(question.id, e.target.value)}
            placeholder="Type your answer here..."
            className="min-h-[120px] border-gray-200 focus:border-sky-500 focus:ring-sky-500"
          />
        );

      case 'essay':
        return (
          <div className="space-y-4">
            <Textarea
              value={(answer as string) || ''}
              onChange={(e) => handleAnswerChange(question.id, e.target.value)}
              placeholder="Write your essay answer here..."
              className="min-h-[300px] border-gray-200 focus:border-sky-500 focus:ring-sky-500"
            />
          </div>
        );

      default:
        return null;
    }
  };

  if (!paper || !attempt) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-orange-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  const question = paper.questions[currentQuestion];
  const answeredCount = Object.keys(answers).length;
  const progress = ((currentQuestion + 1) / paper.questions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <FileText className="w-6 h-6 text-sky-600 mr-2" />
              <span className="font-semibold text-gray-900">{paper.title}</span>
            </div>
            <div className="flex items-center space-x-6">
              <div className={`flex items-center px-4 py-2 rounded-lg ${
                timeLeft < 300 ? 'bg-red-100 text-red-700 animate-pulse' : 'bg-sky-100 text-sky-700'
              }`}>
                <Clock className="w-5 h-5 mr-2" />
                <span className="font-mono font-bold text-lg">{formatTime(timeLeft)}</span>
              </div>
              <Button
                variant="outline"
                onClick={() => setShowSubmitDialog(true)}
                className="border-emerald-500 text-emerald-600 hover:bg-emerald-50"
              >
                <Send className="w-4 h-4 mr-2" />
                Submit
              </Button>
            </div>
          </div>
        </div>
        {/* Progress Bar */}
        <div className="w-full bg-gray-200 h-1">
          <div 
            className="bg-gradient-to-r from-sky-500 to-orange-500 h-1 transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Question Navigation */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="p-4">
                <h3 className="font-semibold text-gray-900 mb-4">Questions</h3>
                <div className="grid grid-cols-5 gap-2">
                  {paper.questions.map((q, idx) => (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQuestion(idx)}
                      className={`w-10 h-10 rounded-lg font-medium text-sm transition-all ${
                        currentQuestion === idx
                          ? 'bg-sky-500 text-white'
                          : answers[q.id]
                          ? 'bg-emerald-100 text-emerald-700 border border-emerald-300'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  ))}
                </div>
                <div className="mt-6 space-y-2 text-sm">
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-emerald-100 border border-emerald-300 rounded mr-2"></div>
                    <span className="text-gray-600">Answered ({answeredCount})</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-gray-100 rounded mr-2"></div>
                    <span className="text-gray-600">Not Answered ({paper.questions.length - answeredCount})</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Question Content */}
          <div className="lg:col-span-3">
            <Card className="min-h-[500px]">
              <CardContent className="p-8">
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm text-gray-500">
                      Question {currentQuestion + 1} of {paper.questions.length}
                    </span>
                    <span className="text-sm font-medium text-sky-600">
                      {question.marks} marks
                    </span>
                  </div>
                  <h2 className="text-xl font-medium text-gray-900 mb-6">
                    {question.question}
                  </h2>
                  {renderQuestion(question)}
                </div>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                    disabled={currentQuestion === 0}
                    className="border-gray-200"
                  >
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Previous
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={handleSaveProgress}
                    className="border-sky-200 text-sky-600 hover:bg-sky-50"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Progress
                  </Button>

                  <Button
                    variant="outline"
                    onClick={() => setCurrentQuestion(Math.min(paper.questions.length - 1, currentQuestion + 1))}
                    disabled={currentQuestion === paper.questions.length - 1}
                    className="border-gray-200"
                  >
                    Next
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Submit Dialog */}
      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Submit Exam?</DialogTitle>
            <DialogDescription>
              You have answered {answeredCount} out of {paper.questions.length} questions.
              {answeredCount < paper.questions.length && (
                <span className="text-amber-600 block mt-2">
                  <AlertCircle className="w-4 h-4 inline mr-1" />
                  You have {paper.questions.length - answeredCount} unanswered questions.
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>
              Continue Exam
            </Button>
            <Button 
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="bg-emerald-500 hover:bg-emerald-600"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Exam'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Time Warning Dialog */}
      <Dialog open={showTimeWarning} onOpenChange={setShowTimeWarning}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-amber-600 flex items-center">
              <Clock className="w-5 h-5 mr-2" />
              Time Warning
            </DialogTitle>
            <DialogDescription>
              You have less than 5 minutes remaining. Please review your answers and submit soon.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={() => setShowTimeWarning(false)}>
              Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ExamPage;
