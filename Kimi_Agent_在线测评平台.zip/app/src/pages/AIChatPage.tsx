import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { PaperDB, AttemptDB, ChatDB } from '@/services/database';
import type { ModelPaper, ExamAttempt, ChatMessage } from '@/types';
import { toast } from 'sonner';
import { 
  ArrowLeft, 
  Send, 
  Bot, 
  User, 
  Sparkles,
  BookOpen,
  Lightbulb,
  AlertCircle
} from 'lucide-react';

// Simulated AI responses based on exam context
const generateAIResponse = (message: string, paper: ModelPaper, attempt: ExamAttempt): string => {
  const lowerMessage = message.toLowerCase();
  
  // Check for common question patterns
  if (lowerMessage.includes('why') && lowerMessage.includes('wrong')) {
    return `Looking at your answers, I can see where the confusion might have occurred. Let's review the key concepts from "${paper.subject}" that this question was testing. The correct approach involves understanding the fundamental principles. Would you like me to explain the step-by-step solution?`;
  }
  
  if (lowerMessage.includes('explain') || lowerMessage.includes('how')) {
    return `I'd be happy to explain! This question tests your understanding of core concepts. Here's the breakdown:\n\n1. First, identify the key elements in the question\n2. Apply the relevant formula/concept\n3. Work through the solution systematically\n\nThe marking scheme shows that partial credit was given for showing your work, which is great! Keep practicing these types of questions.`;
  }
  
  if (lowerMessage.includes('improve') || lowerMessage.includes('better')) {
    return `Based on your performance in this paper (scoring ${attempt.percentage}%), here are my recommendations:\n\n• Focus on the topics where you lost marks\n• Practice similar questions from past papers\n• Review the marking scheme to understand what examiners look for\n• Time management: You spent ${Math.floor(attempt.timeSpent / 60)} minutes on this paper\n\nWould you like specific resources for any topic?`;
  }
  
  if (lowerMessage.includes('mark') || lowerMessage.includes('score')) {
    return `You scored ${attempt.marks} out of ${paper.totalMarks} marks (${attempt.percentage}%) with a grade of ${attempt.grade}. This is ${attempt.percentage && attempt.percentage >= 60 ? 'a solid performance' : 'an area for improvement'}.\n\nYour strongest area was the multiple choice section. Keep up the good work!`;
  }
  
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
    return `Hello! I'm your AI study assistant. I can help you understand your exam results, explain concepts you found challenging, and suggest ways to improve. You scored ${attempt.percentage}% with a grade of ${attempt.grade}. What would you like to know?`;
  }
  
  // Default response
  return `That's a great question! Based on your exam results and the paper content, I can help you with that.\n\nFrom your performance in "${paper.title}", I noticed you did well in some areas and there's room for growth in others. Could you be more specific about what aspect you'd like help with? I can explain concepts, review your answers, or suggest study strategies.`;
};

const AIChatPage: React.FC = () => {
  const { paperId } = useParams<{ paperId: string }>();
  const { currentUser } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [paper, setPaper] = useState<ModelPaper | null>(null);
  const [attempt, setAttempt] = useState<ExamAttempt | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    if (!paperId || !currentUser) return;
    
    const loadedPaper = PaperDB.getById(paperId);
    if (!loadedPaper) {
      toast.error('Paper not found');
      return;
    }
    
    setPaper(loadedPaper);
    
    const loadedAttempt = AttemptDB.getStudentPaperAttempt(currentUser.id, paperId);
    if (!loadedAttempt || loadedAttempt.status !== 'graded') {
      toast.error('You must complete and receive marks for this paper before accessing AI chat');
      return;
    }
    
    setAttempt(loadedAttempt);
    
    // Load chat history
    const chatHistory = ChatDB.getByStudent(currentUser.id).filter(c => c.paperId === paperId);
    setMessages(chatHistory);
    
    // Add welcome message if no history
    if (chatHistory.length === 0) {
      const welcomeMessage = ChatDB.create({
        studentId: currentUser.id,
        paperId: paperId,
        message: 'Welcome to AI Chat!',
        response: `Hello! Congratulations on completing "${loadedPaper.title}"! I'm here to help you understand your results and answer any questions about the exam. You scored ${loadedAttempt.percentage}% with a grade of ${loadedAttempt.grade}. What would you like to know?`,
      });
      setMessages([welcomeMessage]);
    }
    
    setIsLoading(false);
  }, [paperId, currentUser]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !currentUser || !paper || !attempt) return;

    const userMessage = inputMessage.trim();
    setInputMessage('');
    setIsTyping(true);

    // Save user message and get AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(userMessage, paper, attempt);
      
      const chatMessage = ChatDB.create({
        studentId: currentUser.id,
        paperId: paper.id,
        message: userMessage,
        response: aiResponse,
      });

      setMessages(prev => [...prev, chatMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); // Simulate typing delay
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const suggestedQuestions = [
    'Why was my answer wrong?',
    'Can you explain question 3?',
    'How can I improve my score?',
    'What topics should I focus on?',
    'Explain the marking scheme',
  ];

  if (isLoading || !paper || !attempt) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-orange-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/dashboard">
              <Button variant="ghost" className="text-gray-600 hover:text-sky-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center">
              <Bot className="w-6 h-6 text-sky-600 mr-2" />
              <div>
                <h1 className="text-lg font-semibold text-gray-900">AI Study Assistant</h1>
                <p className="text-xs text-gray-500">{paper.title}</p>
              </div>
            </div>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Score Summary */}
        <Card className="mb-6 bg-gradient-to-r from-sky-50 to-orange-50 border-sky-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <BookOpen className="w-5 h-5 text-sky-600 mr-2" />
                <span className="text-gray-700">Your Score:</span>
                <span className="ml-2 font-bold text-sky-600">{attempt.percentage}%</span>
                <span className="ml-2 text-gray-400">({attempt.grade})</span>
              </div>
              <div className="text-sm text-gray-500">
                {attempt.marks} / {paper.totalMarks} marks
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Chat Container */}
        <Card className="border-gray-200 shadow-lg">
          <CardContent className="p-0">
            {/* Messages */}
            <div className="h-[500px] overflow-y-auto p-6 space-y-4">
              {messages.map((msg) => (
                <div key={msg.id} className="space-y-4">
                  {/* User Message */}
                  <div className="flex justify-end">
                    <div className="flex items-start max-w-[80%]">
                      <div className="bg-sky-500 text-white rounded-2xl rounded-tr-sm px-4 py-3">
                        <p className="text-sm">{msg.message}</p>
                      </div>
                      <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center ml-2 flex-shrink-0">
                        <User className="w-4 h-4 text-gray-600" />
                      </div>
                    </div>
                  </div>

                  {/* AI Response */}
                  <div className="flex justify-start">
                    <div className="flex items-start max-w-[80%]">
                      <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-sky-600 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                        <Sparkles className="w-4 h-4 text-white" />
                      </div>
                      <div className="bg-gray-100 rounded-2xl rounded-tl-sm px-4 py-3">
                        <p className="text-sm text-gray-800 whitespace-pre-line">{msg.response}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-start">
                    <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-sky-600 rounded-full flex items-center justify-center mr-2">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-gray-100 rounded-2xl rounded-tl-sm px-4 py-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Suggested Questions */}
            {messages.length < 3 && (
              <div className="px-6 pb-4">
                <p className="text-xs text-gray-500 mb-2 flex items-center">
                  <Lightbulb className="w-3 h-3 mr-1" />
                  Suggested questions:
                </p>
                <div className="flex flex-wrap gap-2">
                  {suggestedQuestions.map((q, idx) => (
                    <button
                      key={idx}
                      onClick={() => setInputMessage(q)}
                      className="text-xs bg-sky-50 text-sky-600 px-3 py-1.5 rounded-full hover:bg-sky-100 transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Area */}
            <div className="border-t border-gray-200 p-4">
              <div className="flex items-center gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask about your exam results..."
                  className="flex-1 border-gray-200 focus:border-sky-500 focus:ring-sky-500"
                  disabled={isTyping}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isTyping}
                  className="bg-sky-500 hover:bg-sky-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-gray-400 mt-2 flex items-center">
                <AlertCircle className="w-3 h-3 mr-1" />
                AI responses are generated based on your exam performance and may not always be perfect.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AIChatPage;
