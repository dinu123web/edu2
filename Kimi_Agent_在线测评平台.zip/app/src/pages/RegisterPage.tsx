import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { GraduationCap, Eye, EyeOff, ArrowLeft, Loader2, Info, Calendar, MapPin, User } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { registerStudent, registerTeacher } = useAuth();
  const [activeTab, setActiveTab] = useState<'student' | 'teacher'>('student');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [studentForm, setStudentForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    nic: '',
    adminNo: '',
    address: '',
    birthdayDay: '',
    birthdayMonth: '',
    birthdayYear: '',
  });
  
  const [teacherForm, setTeacherForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    secretCode: '',
    address: '',
    birthdayDay: '',
    birthdayMonth: '',
    birthdayYear: '',
  });

  const getBirthdayString = (day: string, month: string, year: string) => {
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  };

  const handleStudentRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (studentForm.password !== studentForm.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    if (studentForm.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    if (!studentForm.birthdayDay || !studentForm.birthdayMonth || !studentForm.birthdayYear) {
      toast.error('Please enter your complete birthday');
      return;
    }
    
    setIsLoading(true);
    
    const birthday = getBirthdayString(
      studentForm.birthdayDay,
      studentForm.birthdayMonth,
      studentForm.birthdayYear
    );
    
    const result = await registerStudent({
      firstName: studentForm.firstName,
      lastName: studentForm.lastName,
      email: studentForm.email,
      password: studentForm.password,
      nic: studentForm.nic,
      adminNo: studentForm.adminNo,
      address: studentForm.address,
      birthday: birthday,
    });
    
    if (result.success) {
      toast.success(result.message);
      navigate('/dashboard');
    } else {
      toast.error(result.message);
    }
    setIsLoading(false);
  };

  const handleTeacherRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (teacherForm.password !== teacherForm.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    if (teacherForm.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    if (!teacherForm.birthdayDay || !teacherForm.birthdayMonth || !teacherForm.birthdayYear) {
      toast.error('Please enter your complete birthday');
      return;
    }
    
    setIsLoading(true);

    const birthday = getBirthdayString(
      teacherForm.birthdayDay,
      teacherForm.birthdayMonth,
      teacherForm.birthdayYear
    );
    
    const result = await registerTeacher({
      firstName: teacherForm.firstName,
      lastName: teacherForm.lastName,
      email: teacherForm.email,
      password: teacherForm.password,
      secretCode: teacherForm.secretCode,
      address: teacherForm.address,
      birthday: birthday,
    });
    
    if (result.success) {
      toast.success(result.message);
      navigate('/teacher');
    } else {
      toast.error(result.message);
    }
    setIsLoading(false);
  };

  const days = Array.from({ length: 31 }, (_, i) => (i + 1).toString());
  const months = [
    { value: '1', label: 'January' },
    { value: '2', label: 'February' },
    { value: '3', label: 'March' },
    { value: '4', label: 'April' },
    { value: '5', label: 'May' },
    { value: '6', label: 'June' },
    { value: '7', label: 'July' },
    { value: '8', label: 'August' },
    { value: '9', label: 'September' },
    { value: '10', label: 'October' },
    { value: '11', label: 'November' },
    { value: '12', label: 'December' },
  ];
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 60 }, (_, i) => (currentYear - 18 - i).toString());

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Back Button */}
        <Link to="/" className="inline-flex items-center text-gray-600 hover:text-sky-600 mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        {/* Logo */}
        <div className="flex items-center justify-center mb-8">
          <div className="w-14 h-14 bg-gradient-to-br from-sky-500 to-sky-600 rounded-2xl flex items-center justify-center shadow-lg shadow-sky-200">
            <GraduationCap className="w-8 h-8 text-white" />
          </div>
        </div>

        <Card className="border-0 shadow-2xl shadow-sky-100/50 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-2xl font-bold text-gray-900">Create Account</CardTitle>
            <CardDescription className="text-gray-500">
              Register to start your exam preparation journey
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'student' | 'teacher')} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6 bg-sky-50">
                <TabsTrigger 
                  value="student" 
                  className="data-[state=active]:bg-sky-500 data-[state=active]:text-white"
                >
                  Student
                </TabsTrigger>
                <TabsTrigger 
                  value="teacher"
                  className="data-[state=active]:bg-orange-500 data-[state=active]:text-white"
                >
                  Teacher
                </TabsTrigger>
              </TabsList>

              <TabsContent value="student">
                <form onSubmit={handleStudentRegister} className="space-y-4">
                  {/* Name Fields */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="student-firstName" className="text-gray-700 flex items-center">
                        <User className="w-4 h-4 mr-1" />
                        First Name *
                      </Label>
                      <Input
                        id="student-firstName"
                        placeholder="John"
                        value={studentForm.firstName}
                        onChange={(e) => setStudentForm({ ...studentForm, firstName: e.target.value })}
                        className="border-gray-200 focus:border-sky-500 focus:ring-sky-500"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="student-lastName" className="text-gray-700">Last Name *</Label>
                      <Input
                        id="student-lastName"
                        placeholder="Doe"
                        value={studentForm.lastName}
                        onChange={(e) => setStudentForm({ ...studentForm, lastName: e.target.value })}
                        className="border-gray-200 focus:border-sky-500 focus:ring-sky-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="student-email" className="text-gray-700">Email *</Label>
                    <Input
                      id="student-email"
                      type="email"
                      placeholder="your@email.com"
                      value={studentForm.email}
                      onChange={(e) => setStudentForm({ ...studentForm, email: e.target.value })}
                      className="border-gray-200 focus:border-sky-500 focus:ring-sky-500"
                      required
                    />
                  </div>

                  {/* Birthday */}
                  <div className="space-y-2">
                    <Label className="text-gray-700 flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      Birthday *
                    </Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Select
                        value={studentForm.birthdayDay}
                        onValueChange={(value) => setStudentForm({ ...studentForm, birthdayDay: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Day" />
                        </SelectTrigger>
                        <SelectContent>
                          {days.map(day => (
                            <SelectItem key={day} value={day}>{day}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select
                        value={studentForm.birthdayMonth}
                        onValueChange={(value) => setStudentForm({ ...studentForm, birthdayMonth: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Month" />
                        </SelectTrigger>
                        <SelectContent>
                          {months.map(month => (
                            <SelectItem key={month.value} value={month.value}>{month.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select
                        value={studentForm.birthdayYear}
                        onValueChange={(value) => setStudentForm({ ...studentForm, birthdayYear: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Year" />
                        </SelectTrigger>
                        <SelectContent>
                          {years.map(year => (
                            <SelectItem key={year} value={year}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Address */}
                  <div className="space-y-2">
                    <Label htmlFor="student-address" className="text-gray-700 flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      Address *
                    </Label>
                    <Textarea
                      id="student-address"
                      placeholder="Enter your full address..."
                      value={studentForm.address}
                      onChange={(e) => setStudentForm({ ...studentForm, address: e.target.value })}
                      className="border-gray-200 focus:border-sky-500 focus:ring-sky-500 min-h-[80px]"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="reg-nic" className="text-gray-700">NIC Number *</Label>
                      <Input
                        id="reg-nic"
                        placeholder="NIC"
                        value={studentForm.nic}
                        onChange={(e) => setStudentForm({ ...studentForm, nic: e.target.value })}
                        className="border-gray-200 focus:border-sky-500 focus:ring-sky-500"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reg-adminNo" className="text-gray-700">Admin No *</Label>
                      <Input
                        id="reg-adminNo"
                        placeholder="Admin No"
                        value={studentForm.adminNo}
                        onChange={(e) => setStudentForm({ ...studentForm, adminNo: e.target.value })}
                        className="border-gray-200 focus:border-sky-500 focus:ring-sky-500"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="reg-password" className="text-gray-700">Password *</Label>
                    <div className="relative">
                      <Input
                        id="reg-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        value={studentForm.password}
                        onChange={(e) => setStudentForm({ ...studentForm, password: e.target.value })}
                        className="border-gray-200 focus:border-sky-500 focus:ring-sky-500 pr-10"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reg-confirm" className="text-gray-700">Confirm Password *</Label>
                    <Input
                      id="reg-confirm"
                      type="password"
                      placeholder="••••••••"
                      value={studentForm.confirmPassword}
                      onChange={(e) => setStudentForm({ ...studentForm, confirmPassword: e.target.value })}
                      className="border-gray-200 focus:border-sky-500 focus:ring-sky-500"
                      required
                    />
                  </div>

                  <div className="bg-sky-50 rounded-lg p-3 text-sm text-sky-700">
                    <p className="flex items-start">
                      <Info className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                      One NIC can only be registered with one Admin Number. This cannot be changed later.
                    </p>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating Account...
                      </>
                    ) : (
                      'Register as Student'
                    )}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="teacher">
                <form onSubmit={handleTeacherRegister} className="space-y-4">
                  {/* Name Fields */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="teacher-firstName" className="text-gray-700 flex items-center">
                        <User className="w-4 h-4 mr-1" />
                        First Name *
                      </Label>
                      <Input
                        id="teacher-firstName"
                        placeholder="John"
                        value={teacherForm.firstName}
                        onChange={(e) => setTeacherForm({ ...teacherForm, firstName: e.target.value })}
                        className="border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="teacher-lastName" className="text-gray-700">Last Name *</Label>
                      <Input
                        id="teacher-lastName"
                        placeholder="Smith"
                        value={teacherForm.lastName}
                        onChange={(e) => setTeacherForm({ ...teacherForm, lastName: e.target.value })}
                        className="border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="teacher-email" className="text-gray-700">Email *</Label>
                    <Input
                      id="teacher-email"
                      type="email"
                      placeholder="teacher@school.com"
                      value={teacherForm.email}
                      onChange={(e) => setTeacherForm({ ...teacherForm, email: e.target.value })}
                      className="border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                      required
                    />
                  </div>

                  {/* Birthday */}
                  <div className="space-y-2">
                    <Label className="text-gray-700 flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      Birthday *
                    </Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Select
                        value={teacherForm.birthdayDay}
                        onValueChange={(value) => setTeacherForm({ ...teacherForm, birthdayDay: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Day" />
                        </SelectTrigger>
                        <SelectContent>
                          {days.map(day => (
                            <SelectItem key={day} value={day}>{day}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select
                        value={teacherForm.birthdayMonth}
                        onValueChange={(value) => setTeacherForm({ ...teacherForm, birthdayMonth: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Month" />
                        </SelectTrigger>
                        <SelectContent>
                          {months.map(month => (
                            <SelectItem key={month.value} value={month.value}>{month.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select
                        value={teacherForm.birthdayYear}
                        onValueChange={(value) => setTeacherForm({ ...teacherForm, birthdayYear: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Year" />
                        </SelectTrigger>
                        <SelectContent>
                          {years.map(year => (
                            <SelectItem key={year} value={year}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Address */}
                  <div className="space-y-2">
                    <Label htmlFor="teacher-address" className="text-gray-700 flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      Address *
                    </Label>
                    <Textarea
                      id="teacher-address"
                      placeholder="Enter your full address..."
                      value={teacherForm.address}
                      onChange={(e) => setTeacherForm({ ...teacherForm, address: e.target.value })}
                      className="border-gray-200 focus:border-orange-500 focus:ring-orange-500 min-h-[80px]"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="secret-code" className="text-gray-700">Secret Code *</Label>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="w-4 h-4 text-gray-400 cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">Contact administration to get your teacher secret code.</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Input
                      id="secret-code"
                      type="password"
                      placeholder="Enter secret code"
                      value={teacherForm.secretCode}
                      onChange={(e) => setTeacherForm({ ...teacherForm, secretCode: e.target.value })}
                      className="border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="teacher-password" className="text-gray-700">Password *</Label>
                    <div className="relative">
                      <Input
                        id="teacher-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        value={teacherForm.password}
                        onChange={(e) => setTeacherForm({ ...teacherForm, password: e.target.value })}
                        className="border-gray-200 focus:border-orange-500 focus:ring-orange-500 pr-10"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="teacher-confirm" className="text-gray-700">Confirm Password *</Label>
                    <Input
                      id="teacher-confirm"
                      type="password"
                      placeholder="••••••••"
                      value={teacherForm.confirmPassword}
                      onChange={(e) => setTeacherForm({ ...teacherForm, confirmPassword: e.target.value })}
                      className="border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                      required
                    />
                  </div>

                  <div className="bg-orange-50 rounded-lg p-3 text-sm text-orange-700">
                    <p className="flex items-start">
                      <Info className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                      Demo secret code: <strong className="ml-1">EDU2024TEACHER</strong>
                    </p>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating Account...
                      </>
                    ) : (
                      'Register as Teacher'
                    )}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            <div className="mt-6 text-center">
              <p className="text-gray-600">
                Already have an account?{' '}
                <Link to="/login" className="text-sky-600 hover:text-sky-700 font-medium">
                  Login here
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RegisterPage;
