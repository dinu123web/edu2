import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AttemptDB, PaperDB } from '@/services/database';
import type { ExamAttempt, ModelPaper } from '@/types';
import { toast } from 'sonner';
import { 
  CheckCircle, 
  XCircle, 
  ArrowLeft, 
  MessageCircle, 
  FileText,
  Award,
  Clock,
  TrendingUp,
  AlertTriangle,
  BookOpen
} from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const ResultsPage: React.FC = () => {
  const { attemptId } = useParams<{ attemptId: string }>();
  const [attempt, setAttempt] = useState<ExamAttempt | null>(null);
  const [paper, setPaper] = useState<ModelPaper | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!attemptId) return;
    
    const loadedAttempt = AttemptDB.getById(attemptId);
    if (!loadedAttempt) {
      toast.error('Result not found');
      return;
    }
    
    setAttempt(loadedAttempt);
    const loadedPaper = PaperDB.getById(loadedAttempt.paperId);
    setPaper(loadedPaper || null);
    setIsLoading(false);
  }, [attemptId]);

  const getGradeColor = (grade?: string) => {
    switch (grade) {
      case 'A+': return 'text-emerald-600 bg-emerald-100';
      case 'A': return 'text-emerald-600 bg-emerald-100';
      case 'B+': return 'text-blue-600 bg-blue-100';
      case 'B': return 'text-blue-600 bg-blue-100';
      case 'C': return 'text-amber-600 bg-amber-100';
      case 'D': return 'text-orange-600 bg-orange-100';
      default: return 'text-red-600 bg-red-100';
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  if (isLoading || !attempt || !paper) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-orange-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/dashboard">
              <Button variant="ghost" className="text-gray-600 hover:text-sky-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">Exam Results</h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Score Card */}
        <Card className="mb-8 border-0 shadow-xl bg-gradient-to-br from-sky-500 to-sky-600 text-white">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="text-center md:text-left mb-6 md:mb-0">
                <h2 className="text-2xl font-bold mb-2">{paper.title}</h2>
                <p className="text-sky-100">{paper.description}</p>
                <div className="flex items-center justify-center md:justify-start gap-4 mt-4 text-sm text-sky-100">
                  <span className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    Time: {formatTime(attempt.timeSpent)}
                  </span>
                  <span className="flex items-center">
                    <FileText className="w-4 h-4 mr-1" />
                    {paper.questions.length} Questions
                  </span>
                </div>
              </div>
              <div className="text-center">
                <div className="w-32 h-32 bg-white/20 backdrop-blur rounded-full flex flex-col items-center justify-center mb-3">
                  <span className="text-4xl font-bold">{attempt.percentage}%</span>
                  <span className="text-sm text-sky-100">Score</span>
                </div>
                <Badge className={`text-lg px-4 py-1 ${getGradeColor(attempt.grade)}`}>
                  Grade: {attempt.grade}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <Award className="w-10 h-10 text-sky-600 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">Marks Obtained</p>
              <p className="text-3xl font-bold text-gray-900">
                {attempt.marks} <span className="text-lg text-gray-400">/ {paper.totalMarks}</span>
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="w-10 h-10 text-orange-500 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">Percentage</p>
              <p className="text-3xl font-bold text-gray-900">{attempt.percentage}%</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <BookOpen className="w-10 h-10 text-emerald-600 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">Questions Answered</p>
              <p className="text-3xl font-bold text-gray-900">
                {Object.keys(attempt.answers).length} <span className="text-lg text-gray-400">/ {paper.questions.length}</span>
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <Link to={`/chat/${paper.id}`} className="flex-1">
            <Button className="w-full bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700">
              <MessageCircle className="w-4 h-4 mr-2" />
              Ask AI About Results
            </Button>
          </Link>
          <Link to="/progress" className="flex-1">
            <Button variant="outline" className="w-full border-orange-400 text-orange-600 hover:bg-orange-50">
              <TrendingUp className="w-4 h-4 mr-2" />
              View Progress Report
            </Button>
          </Link>
        </div>

        {/* Marking Scheme */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2 text-sky-600" />
              Marking Scheme & Answers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {paper.questions.map((question, idx) => {
                const studentAnswer = attempt.answers[question.id];
                const markingScheme = paper.markingScheme[question.id];
                let isCorrect = false;
                
                if (markingScheme) {
                  if (Array.isArray(markingScheme.correctAnswer)) {
                    isCorrect = Array.isArray(studentAnswer) && markingScheme.correctAnswer.every(ans => studentAnswer.includes(ans));
                  } else {
                    isCorrect = typeof studentAnswer === 'string' && studentAnswer.toLowerCase() === (markingScheme.correctAnswer as string).toLowerCase();
                  }
                }

                return (
                  <AccordionItem key={question.id} value={question.id}>
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex items-center text-left w-full pr-4">
                        <span className="w-8 h-8 rounded-full bg-sky-100 text-sky-600 flex items-center justify-center text-sm font-medium mr-3 flex-shrink-0">
                          {idx + 1}
                        </span>
                        <span className="flex-1 truncate">{question.question}</span>
                        {isCorrect ? (
                          <CheckCircle className="w-5 h-5 text-emerald-500 ml-3 flex-shrink-0" />
                        ) : (
                          <XCircle className="w-5 h-5 text-red-500 ml-3 flex-shrink-0" />
                        )}
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="pl-11 space-y-4">
                        <div>
                          <p className="text-sm font-medium text-gray-700 mb-1">Your Answer:</p>
                          <p className={`text-sm ${isCorrect ? 'text-emerald-600' : 'text-red-600'}`}>
                            {Array.isArray(studentAnswer) ? studentAnswer.join(', ') : studentAnswer || 'Not answered'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700 mb-1">Correct Answer:</p>
                          <p className="text-sm text-emerald-600">
                            {Array.isArray(markingScheme?.correctAnswer) 
                              ? markingScheme.correctAnswer.join(', ') 
                              : markingScheme?.correctAnswer}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700 mb-1">Marks:</p>
                          <p className="text-sm text-gray-600">
                            {isCorrect ? markingScheme?.marks : 0} / {markingScheme?.marks}
                          </p>
                        </div>
                        {markingScheme?.explanation && (
                          <div className="bg-sky-50 rounded-lg p-3">
                            <p className="text-sm font-medium text-sky-700 mb-1">Explanation:</p>
                            <p className="text-sm text-sky-600">{markingScheme.explanation}</p>
                          </div>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </CardContent>
        </Card>

        {/* Plagiarism Check Results */}
        {attempt.plagiarismCheck && attempt.plagiarismCheck.score > 0 && (
          <Card className="border-amber-200 bg-amber-50">
            <CardHeader>
              <CardTitle className="flex items-center text-amber-800">
                <AlertTriangle className="w-5 h-5 mr-2" />
                Plagiarism Alert
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-amber-700 mb-4">
                Similarity Score: <strong>{attempt.plagiarismCheck.score}%</strong>
              </p>
              {attempt.plagiarismCheck.sources.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-amber-800">Detected Sources:</p>
                  <ul className="list-disc list-inside text-sm text-amber-700">
                    {attempt.plagiarismCheck.sources.map((source, idx) => (
                      <li key={idx}>
                        {source.title} - {source.similarity}% similarity
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default ResultsPage;
