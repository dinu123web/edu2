import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { PaperDB, AttemptDB, ClassAverageDB, StudentDB } from '@/services/database';
import type { ModelPaper, ExamAttempt, ClassAverage, Student } from '@/types';
import { toast } from 'sonner';
import { 
  GraduationCap, 
  BookOpen, 
  Users, 
  TrendingUp, 
  LogOut,
  Plus,
  BarChart3,
  Clock,
  FileText,
  Video,
  ChevronRight,
  AlertCircle
} from 'lucide-react';

const TeacherDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const [papers, setPapers] = useState<ModelPaper[]>([]);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [classAverages, setClassAverages] = useState<ClassAverage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setIsLoading(true);
    
    // Load all papers
    const allPapers = PaperDB.getAll();
    setPapers(allPapers);
    
    // Load all attempts
    const allAttempts = AttemptDB.getAll();
    setAttempts(allAttempts);
    
    // Load all students
    const allStudents = StudentDB.getAll();
    setStudents(allStudents);
    
    // Load class averages
    const averages = ClassAverageDB.getAll();
    setClassAverages(averages);
    
    setIsLoading(false);
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigate('/');
  };

  const getPaperStats = (paperId: string) => {
    const paperAttempts = attempts.filter(a => a.paperId === paperId);
    const submitted = paperAttempts.filter(a => a.status === 'graded' || a.status === 'submitted').length;
    const graded = paperAttempts.filter(a => a.status === 'graded').length;
    const avg = classAverages.find(a => a.paperId === paperId);
    return { submitted, graded, average: avg?.averageMarks || 0 };
  };

  const getExpiringPapers = () => {
    const now = new Date();
    const oneWeek = 7 * 24 * 60 * 60 * 1000;
    return papers.filter(p => {
      const expiresAt = new Date(p.expiresAt);
      const timeUntilExpiry = expiresAt.getTime() - now.getTime();
      return timeUntilExpiry > 0 && timeUntilExpiry < oneWeek;
    });
  };

  const teacher = currentUser as any;

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-sky-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-orange-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-orange-600 to-sky-600 bg-clip-text text-transparent">
                EduExam Teacher Portal
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 text-sm text-gray-600">
                <span className="font-medium">{teacher?.name}</span>
                <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                  Teacher
                </Badge>
              </div>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-gray-600 hover:text-red-600">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome, <span className="text-orange-600">{teacher?.name?.split(' ')[0]}</span>!
          </h1>
          <p className="text-gray-600">
            Manage your model papers, track student progress, and upload resources.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Link to="/teacher/upload">
            <Button className="w-full h-full py-6 bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 flex flex-col items-center">
              <Plus className="w-6 h-6 mb-2" />
              <span>Upload Paper</span>
            </Button>
          </Link>
          <Link to="/teacher/papers">
            <Button variant="outline" className="w-full h-full py-6 border-orange-400 text-orange-600 hover:bg-orange-50 flex flex-col items-center">
              <BookOpen className="w-6 h-6 mb-2" />
              <span>My Papers</span>
            </Button>
          </Link>
          <Link to="/teacher/class-progress">
            <Button variant="outline" className="w-full h-full py-6 border-emerald-400 text-emerald-600 hover:bg-emerald-50 flex flex-col items-center">
              <BarChart3 className="w-6 h-6 mb-2" />
              <span>Class Progress</span>
            </Button>
          </Link>
          <Link to="/teacher/upload?type=recording">
            <Button variant="outline" className="w-full h-full py-6 border-purple-400 text-purple-600 hover:bg-purple-50 flex flex-col items-center">
              <Video className="w-6 h-6 mb-2" />
              <span>Add Recording</span>
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-sky-500 to-sky-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sky-100 text-sm">Total Papers</p>
                  <p className="text-3xl font-bold">{papers.length}</p>
                </div>
                <BookOpen className="w-10 h-10 text-sky-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">Registered Students</p>
                  <p className="text-3xl font-bold">{students.length}</p>
                </div>
                <Users className="w-10 h-10 text-orange-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm">Total Submissions</p>
                  <p className="text-3xl font-bold">{attempts.filter(a => a.status === 'graded' || a.status === 'submitted').length}</p>
                </div>
                <FileText className="w-10 h-10 text-emerald-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Class Average</p>
                  <p className="text-3xl font-bold">
                    {classAverages.length > 0 
                      ? Math.round(classAverages.reduce((acc, a) => acc + a.averageMarks, 0) / classAverages.length)
                      : 0}%
                  </p>
                </div>
                <TrendingUp className="w-10 h-10 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* My Papers */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                <BookOpen className="w-5 h-5 mr-2 text-sky-600" />
                My Model Papers
              </h2>
              <Link to="/teacher/papers">
                <Button variant="ghost" size="sm" className="text-sky-600">
                  View All
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600"></div>
              </div>
            ) : papers.length === 0 ? (
              <Card className="bg-gray-50 border-gray-100">
                <CardContent className="p-12 text-center">
                  <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No papers uploaded yet.</p>
                  <Link to="/teacher/upload">
                    <Button className="mt-4 bg-sky-500 hover:bg-sky-600">
                      <Plus className="w-4 h-4 mr-2" />
                      Upload Your First Paper
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {papers.slice(0, 5).map((paper) => {
                  const stats = getPaperStats(paper.id);
                  const isExpiringSoon = new Date(paper.expiresAt).getTime() - new Date().getTime() < 7 * 24 * 60 * 60 * 1000;
                  
                  return (
                    <Card key={paper.id} className="hover:shadow-lg transition-shadow border-gray-100">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-semibold text-gray-900">{paper.title}</h3>
                              {isExpiringSoon && (
                                <Badge className="bg-amber-100 text-amber-700">
                                  <Clock className="w-3 h-3 mr-1" />
                                  Expiring Soon
                                </Badge>
                              )}
                              {!paper.isActive && (
                                <Badge variant="secondary">Inactive</Badge>
                              )}
                            </div>
                            <p className="text-gray-600 text-sm mb-3">{paper.description}</p>
                            <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                              <span className="flex items-center">
                                <Clock className="w-4 h-4 mr-1" />
                                {paper.duration} min
                              </span>
                              <span className="flex items-center">
                                <FileText className="w-4 h-4 mr-1" />
                                {paper.questions.length} questions
                              </span>
                              <span className="flex items-center">
                                <Users className="w-4 h-4 mr-1" />
                                {stats.submitted} submissions
                              </span>
                              {paper.zoomRecording && (
                                <span className="flex items-center text-purple-600">
                                  <Video className="w-4 h-4 mr-1" />
                                  Recording
                                </span>
                              )}
                            </div>
                            {stats.graded > 0 && (
                              <div className="flex items-center gap-3">
                                <span className="text-sm text-gray-600">Class Average:</span>
                                <span className="font-semibold text-sky-600">{Math.round(stats.average)}%</span>
                                <Progress value={stats.average} className="w-24 h-2" />
                              </div>
                            )}
                          </div>
                          <div className="ml-4 flex flex-col gap-2">
                            <Link to={`/teacher/upload?edit=${paper.id}`}>
                              <Button variant="outline" size="sm" className="border-sky-500 text-sky-600 hover:bg-sky-50">
                                Edit
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Expiring Soon */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <CardTitle className="text-lg flex items-center text-amber-800">
                  <Clock className="w-5 h-5 mr-2" />
                  Expiring Soon
                </CardTitle>
              </CardHeader>
              <CardContent>
                {getExpiringPapers().length === 0 ? (
                  <p className="text-amber-700 text-sm">No papers expiring within a week.</p>
                ) : (
                  <div className="space-y-3">
                    {getExpiringPapers().map(paper => (
                      <div key={paper.id} className="flex items-center justify-between">
                        <span className="text-sm text-amber-800 truncate flex-1">{paper.title}</span>
                        <span className="text-xs text-amber-600">
                          {new Date(paper.expiresAt).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Submissions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                {attempts.filter(a => a.status === 'submitted' || a.status === 'graded').length === 0 ? (
                  <p className="text-gray-500 text-sm text-center py-4">
                    No submissions yet.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {attempts
                      .filter(a => a.status === 'submitted' || a.status === 'graded')
                      .slice(-5)
                      .reverse()
                      .map((attempt) => {
                        const paper = papers.find(p => p.id === attempt.paperId);
                        const student = students.find(s => s.id === attempt.studentId);
                        return (
                          <div key={attempt.id} className="flex items-center gap-3 text-sm border-b border-gray-100 last:border-0 pb-2 last:pb-0">
                            <div className={`w-2 h-2 rounded-full ${
                              attempt.status === 'graded' ? 'bg-emerald-500' : 'bg-amber-500'
                            }`} />
                            <div className="flex-1">
                              <p className="text-gray-900 truncate">{student?.name || 'Unknown'}</p>
                              <p className="text-gray-400 text-xs">{paper?.title || 'Unknown Paper'}</p>
                            </div>
                            {attempt.percentage !== undefined && (
                              <span className={`font-medium ${
                                attempt.percentage >= 60 ? 'text-emerald-600' : 'text-orange-600'
                              }`}>
                                {attempt.percentage}%
                              </span>
                            )}
                          </div>
                        );
                      })}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Active Papers</span>
                    <span className="font-medium">{papers.filter(p => p.isActive).length}</span>
                  </div>
                  <Progress value={(papers.filter(p => p.isActive).length / Math.max(1, papers.length)) * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Graded Submissions</span>
                    <span className="font-medium">
                      {attempts.filter(a => a.status === 'graded').length} / {attempts.filter(a => a.status === 'submitted' || a.status === 'graded').length}
                    </span>
                  </div>
                  <Progress 
                    value={
                      (attempts.filter(a => a.status === 'graded').length / 
                      Math.max(1, attempts.filter(a => a.status === 'submitted' || a.status === 'graded').length)) * 100
                    } 
                    className="h-2" 
                  />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">With Recordings</span>
                    <span className="font-medium">{papers.filter(p => p.zoomRecording).length}</span>
                  </div>
                  <Progress value={(papers.filter(p => p.zoomRecording).length / Math.max(1, papers.length)) * 100} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
