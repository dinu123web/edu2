import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { AttemptDB, PaperDB, ClassAverageDB } from '@/services/database';
import type { ExamAttempt, ModelPaper, ClassAverage } from '@/types';
import { 
  ArrowLeft, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Calendar,
  BarChart3,
  Target,
  Zap
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
} from 'recharts';

const ProgressReportPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [papers, setPapers] = useState<ModelPaper[]>([]);
  const [classAverages, setClassAverages] = useState<ClassAverage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!currentUser) return;
    
    const studentAttempts = AttemptDB.getByStudent(currentUser.id);
    const gradedAttempts = studentAttempts.filter(a => a.status === 'graded');
    setAttempts(gradedAttempts);
    
    const allPapers = PaperDB.getAll();
    setPapers(allPapers);
    
    const averages = ClassAverageDB.getAll();
    setClassAverages(averages);
    
    setIsLoading(false);
  }, [currentUser]);

  const getProgressData = () => {
    return attempts.map((attempt, index) => {
      const paper = papers.find(p => p.id === attempt.paperId);
      const classAvg = classAverages.find(a => a.paperId === attempt.paperId);
      return {
        name: `Paper ${index + 1}`,
        fullName: paper?.title || `Paper ${index + 1}`,
        yourScore: attempt.percentage,
        classAverage: classAvg?.averageMarks || 0,
        date: new Date(attempt.submittedAt || attempt.startedAt).toLocaleDateString(),
      };
    });
  };

  const getSubjectData = () => {
    const subjectMap: { [key: string]: { total: number; count: number } } = {};
    
    attempts.forEach(attempt => {
      const paper = papers.find(p => p.id === attempt.paperId);
      if (paper) {
        if (!subjectMap[paper.subject]) {
          subjectMap[paper.subject] = { total: 0, count: 0 };
        }
        subjectMap[paper.subject].total += attempt.percentage || 0;
        subjectMap[paper.subject].count += 1;
      }
    });

    return Object.entries(subjectMap).map(([subject, data]) => ({
      subject,
      average: Math.round(data.total / data.count),
      fullMark: 100,
    }));
  };

  const getStats = () => {
    if (attempts.length === 0) return null;

    const percentages = attempts.map(a => a.percentage || 0);
    const totalPapers = papers.length;
    const completedPapers = attempts.length;
    const averageScore = percentages.reduce((a, b) => a + b, 0) / percentages.length;
    const highestScore = Math.max(...percentages);
    const lowestScore = Math.min(...percentages);
    
    // Calculate trend
    let trend: 'up' | 'down' | 'stable' = 'stable';
    if (percentages.length >= 2) {
      const recent = percentages.slice(-3);
      const avgRecent = recent.reduce((a, b) => a + b, 0) / recent.length;
      const avgPrevious = percentages.slice(0, -3).reduce((a, b) => a + b, 0) / Math.max(1, percentages.length - 3);
      
      if (avgRecent > avgPrevious + 5) trend = 'up';
      else if (avgRecent < avgPrevious - 5) trend = 'down';
    }

    return {
      totalPapers,
      completedPapers,
      averageScore: Math.round(averageScore),
      highestScore,
      lowestScore,
      trend,
    };
  };

  const getGradeDistribution = () => {
    const grades: { [key: string]: number } = { 'A+': 0, 'A': 0, 'B+': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0 };
    attempts.forEach(attempt => {
      if (attempt.grade) {
        grades[attempt.grade] = (grades[attempt.grade] || 0) + 1;
      }
    });
    return Object.entries(grades).map(([grade, count]) => ({ grade, count }));
  };

  const stats = getStats();
  const progressData = getProgressData();
  const subjectData = getSubjectData();
  const gradeDistribution = getGradeDistribution();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-orange-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/dashboard">
              <Button variant="ghost" className="text-gray-600 hover:text-sky-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">Progress Report</h1>
            <div className="w-24"></div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview Stats */}
        {stats ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-sky-500 to-sky-600 text-white border-0">
              <CardContent className="p-6">
                <p className="text-sky-100 text-sm mb-1">Average Score</p>
                <div className="flex items-end">
                  <span className="text-3xl font-bold">{stats.averageScore}%</span>
                  {stats.trend === 'up' && <TrendingUp className="w-5 h-5 ml-2 text-emerald-300" />}
                  {stats.trend === 'down' && <TrendingDown className="w-5 h-5 ml-2 text-red-300" />}
                  {stats.trend === 'stable' && <Minus className="w-5 h-5 ml-2 text-sky-300" />}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <p className="text-gray-500 text-xs mb-1">Papers Completed</p>
                <p className="text-3xl font-bold text-gray-900">
                  {stats.completedPapers} <span className="text-lg text-gray-400">/ {stats.totalPapers}</span>
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <p className="text-gray-500 text-xs mb-1">Highest Score</p>
                <p className="text-3xl font-bold text-emerald-600">{stats.highestScore}%</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <p className="text-gray-500 text-xs mb-1">Lowest Score</p>
                <p className="text-3xl font-bold text-orange-600">{stats.lowestScore}%</p>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card className="mb-8">
            <CardContent className="p-12 text-center">
              <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No data available yet. Complete some papers to see your progress!</p>
            </CardContent>
          </Card>
        )}

        {stats && (
          <>
            {/* Progress Chart */}
            <div className="grid lg:grid-cols-2 gap-8 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <TrendingUp className="w-5 h-5 mr-2 text-sky-600" />
                    Score Progress Over Time
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={progressData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="name" stroke="#6b7280" />
                      <YAxis stroke="#6b7280" domain={[0, 100]} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }}
                        formatter={(value: number) => [`${value}%`, '']}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="yourScore" 
                        name="Your Score" 
                        stroke="#0ea5e9" 
                        strokeWidth={2}
                        dot={{ fill: '#0ea5e9', strokeWidth: 2 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="classAverage" 
                        name="Class Average" 
                        stroke="#f97316" 
                        strokeWidth={2}
                        strokeDasharray="5 5"
                        dot={{ fill: '#f97316', strokeWidth: 2 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Target className="w-5 h-5 mr-2 text-orange-500" />
                    Grade Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={gradeDistribution}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="grade" stroke="#6b7280" />
                      <YAxis stroke="#6b7280" />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }}
                      />
                      <Bar dataKey="count" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Subject Performance */}
            {subjectData.length > 0 && (
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Zap className="w-5 h-5 mr-2 text-emerald-500" />
                    Performance by Subject
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={subjectData}>
                      <PolarGrid stroke="#e5e7eb" />
                      <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b7280' }} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#6b7280' }} />
                      <Radar
                        name="Your Average"
                        dataKey="average"
                        stroke="#0ea5e9"
                        fill="#0ea5e9"
                        fillOpacity={0.3}
                      />
                      <Legend />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }}
                        formatter={(value: number) => [`${value}%`, '']}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {/* Recent Attempts Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Calendar className="w-5 h-5 mr-2 text-sky-600" />
                  Recent Exam History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Paper</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Date</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Score</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Grade</th>
                        <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Class Avg</th>
                      </tr>
                    </thead>
                    <tbody>
                      {attempts.slice().reverse().map((attempt) => {
                        const paper = papers.find(p => p.id === attempt.paperId);
                        const classAvg = classAverages.find(a => a.paperId === attempt.paperId);
                        return (
                          <tr key={attempt.id} className="border-b border-gray-100 hover:bg-gray-50">
                            <td className="py-3 px-4 text-sm text-gray-900">{paper?.title || 'Unknown'}</td>
                            <td className="py-3 px-4 text-sm text-gray-600">
                              {new Date(attempt.submittedAt || attempt.startedAt).toLocaleDateString()}
                            </td>
                            <td className="py-3 px-4">
                              <span className={`font-medium ${
                                (attempt.percentage || 0) >= 60 ? 'text-emerald-600' : 'text-orange-600'
                              }`}>
                                {attempt.percentage}%
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <Badge className={`
                                ${attempt.grade?.startsWith('A') ? 'bg-emerald-100 text-emerald-700' : ''}
                                ${attempt.grade?.startsWith('B') ? 'bg-blue-100 text-blue-700' : ''}
                                ${attempt.grade === 'C' ? 'bg-amber-100 text-amber-700' : ''}
                                ${attempt.grade === 'D' ? 'bg-orange-100 text-orange-700' : ''}
                                ${attempt.grade === 'F' ? 'bg-red-100 text-red-700' : ''}
                              `}>
                                {attempt.grade}
                              </Badge>
                            </td>
                            <td className="py-3 px-4 text-sm text-gray-600">
                              {classAvg ? `${Math.round(classAvg.averageMarks)}%` : 'N/A'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
};

export default ProgressReportPage;
