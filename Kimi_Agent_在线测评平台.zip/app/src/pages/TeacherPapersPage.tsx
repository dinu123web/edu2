import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { PaperDB, AttemptDB, ClassAverageDB } from '@/services/database';
import type { ModelPaper } from '@/types';
import { toast } from 'sonner';
import { 
  ArrowLeft, 
  Plus, 
  Search,
  Clock,
  FileText,
  Users,
  Video,
  Edit,
  Trash2,
  AlertCircle,
  MoreVertical,
  BarChart3
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const TeacherPapersPage: React.FC = () => {
  const [papers, setPapers] = useState<ModelPaper[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPaper, setSelectedPaper] = useState<ModelPaper | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPapers();
  }, []);

  const loadPapers = () => {
    setIsLoading(true);
    const allPapers = PaperDB.getAll();
    setPapers(allPapers);
    setIsLoading(false);
  };

  const handleDelete = () => {
    if (!selectedPaper) return;
    
    const success = PaperDB.delete(selectedPaper.id);
    if (success) {
      toast.success('Paper deleted successfully');
      loadPapers();
    } else {
      toast.error('Failed to delete paper');
    }
    setShowDeleteDialog(false);
    setSelectedPaper(null);
  };

  const handleToggleActive = (paper: ModelPaper) => {
    const updated = PaperDB.update(paper.id, { isActive: !paper.isActive });
    if (updated) {
      toast.success(`Paper ${updated.isActive ? 'activated' : 'deactivated'}`);
      loadPapers();
    }
  };

  const getPaperStats = (paperId: string) => {
    const attempts = AttemptDB.getByPaper(paperId);
    return {
      submissions: attempts.filter(a => a.status === 'submitted' || a.status === 'graded').length,
      graded: attempts.filter(a => a.status === 'graded').length,
      average: ClassAverageDB.getByPaper(paperId)?.averageMarks || 0,
    };
  };

  const filteredPapers = papers.filter(paper => 
    paper.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    paper.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-sky-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/teacher">
              <Button variant="ghost" className="text-gray-600 hover:text-orange-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">My Papers</h1>
            <Link to="/teacher/upload">
              <Button className="bg-sky-500 hover:bg-sky-600">
                <Plus className="w-4 h-4 mr-2" />
                New Paper
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Search papers by title or subject..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 border-gray-200 focus:border-sky-500 focus:ring-sky-500"
          />
        </div>

        {/* Papers List */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600"></div>
          </div>
        ) : filteredPapers.length === 0 ? (
          <Card className="bg-gray-50 border-gray-100">
            <CardContent className="p-12 text-center">
              <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No papers found.</p>
              <Link to="/teacher/upload">
                <Button className="mt-4 bg-sky-500 hover:bg-sky-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Create New Paper
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredPapers.map((paper) => {
              const stats = getPaperStats(paper.id);
              const isExpiringSoon = new Date(paper.expiresAt).getTime() - new Date().getTime() < 7 * 24 * 60 * 60 * 1000;
              
              return (
                <Card key={paper.id} className="hover:shadow-lg transition-shadow border-gray-100">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">{paper.title}</h3>
                          <Badge className={paper.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'}>
                            {paper.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                          {isExpiringSoon && (
                            <Badge className="bg-amber-100 text-amber-700">
                              <Clock className="w-3 h-3 mr-1" />
                              Expiring Soon
                            </Badge>
                          )}
                        </div>
                        <p className="text-gray-600 text-sm mb-3">{paper.description}</p>
                        
                        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-4">
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {paper.duration} minutes
                          </span>
                          <span className="flex items-center">
                            <FileText className="w-4 h-4 mr-1" />
                            {paper.questions.length} questions
                          </span>
                          <span className="flex items-center">
                            <Users className="w-4 h-4 mr-1" />
                            {stats.submissions} submissions
                          </span>
                          {paper.zoomRecording && (
                            <span className="flex items-center text-purple-600">
                              <Video className="w-4 h-4 mr-1" />
                              Has Recording
                            </span>
                          )}
                          <span className="text-gray-400">
                            Expires: {new Date(paper.expiresAt).toLocaleDateString()}
                          </span>
                        </div>

                        {stats.graded > 0 && (
                          <div className="flex items-center gap-4 bg-sky-50 rounded-lg p-3">
                            <div className="flex items-center gap-2">
                              <BarChart3 className="w-4 h-4 text-sky-600" />
                              <span className="text-sm text-gray-600">Class Average:</span>
                              <span className="font-semibold text-sky-600">{Math.round(stats.average)}%</span>
                            </div>
                            <div className="h-4 w-px bg-sky-200"></div>
                            <div className="text-sm text-gray-600">
                              {stats.graded} graded / {stats.submissions} total
                            </div>
                          </div>
                        )}
                      </div>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link to={`/teacher/upload?edit=${paper.id}`}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit Paper
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleToggleActive(paper)}>
                            {paper.isActive ? (
                              <>
                                <AlertCircle className="w-4 h-4 mr-2" />
                                Deactivate
                              </>
                            ) : (
                              <>
                                <BarChart3 className="w-4 h-4 mr-2" />
                                Activate
                              </>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="text-red-600"
                            onClick={() => {
                              setSelectedPaper(paper);
                              setShowDeleteDialog(true);
                            }}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Delete Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Paper?</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{selectedPaper?.title}"? This action cannot be undone.
              {AttemptDB.getByPaper(selectedPaper?.id || '').length > 0 && (
                <span className="text-amber-600 block mt-2">
                  <AlertCircle className="w-4 h-4 inline mr-1" />
                  This paper has student submissions. Deleting it will remove all associated data.
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleDelete} className="bg-red-500 hover:bg-red-600">
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TeacherPapersPage;
