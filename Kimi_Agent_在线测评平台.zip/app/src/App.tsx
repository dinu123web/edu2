import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { Toaster } from '@/components/ui/sonner';

// Pages
import HomePage from '@/pages/HomePage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import StudentDashboard from '@/pages/StudentDashboard';
import TeacherDashboard from '@/pages/TeacherDashboard';
import ExamPage from '@/pages/ExamPage';
import ResultsPage from '@/pages/ResultsPage';
import ProgressReportPage from '@/pages/ProgressReportPage';
import AIChatPage from '@/pages/AIChatPage';
import TeacherPapersPage from '@/pages/TeacherPapersPage';
import TeacherUploadPage from '@/pages/TeacherUploadPage';
import ClassProgressPage from '@/pages/ClassProgressPage';
import ZoomRecordingsPage from '@/pages/ZoomRecordingsPage';

// Protected Route Components
const ProtectedRoute: React.FC<{ children: React.ReactNode; allowedRole?: 'student' | 'teacher' }> = ({ 
  children, 
  allowedRole 
}) => {
  const { isAuthenticated, currentUser, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-orange-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRole && currentUser?.role !== allowedRole) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, currentUser, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-orange-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600"></div>
      </div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to={currentUser?.role === 'teacher' ? '/teacher' : '/dashboard'} replace />;
  }

  return <>{children}</>;
};

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<HomePage />} />
      <Route 
        path="/login" 
        element={
          <PublicRoute>
            <LoginPage />
          </PublicRoute>
        } 
      />
      <Route 
        path="/register" 
        element={
          <PublicRoute>
            <RegisterPage />
          </PublicRoute>
        } 
      />

      {/* Student Routes */}
      <Route 
        path="/dashboard" 
        element={
          <ProtectedRoute allowedRole="student">
            <StudentDashboard />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/exam/:paperId" 
        element={
          <ProtectedRoute allowedRole="student">
            <ExamPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/results/:attemptId" 
        element={
          <ProtectedRoute allowedRole="student">
            <ResultsPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/progress" 
        element={
          <ProtectedRoute allowedRole="student">
            <ProgressReportPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/chat/:paperId" 
        element={
          <ProtectedRoute allowedRole="student">
            <AIChatPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/recordings" 
        element={
          <ProtectedRoute allowedRole="student">
            <ZoomRecordingsPage />
          </ProtectedRoute>
        } 
      />

      {/* Teacher Routes */}
      <Route 
        path="/teacher" 
        element={
          <ProtectedRoute allowedRole="teacher">
            <TeacherDashboard />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/teacher/papers" 
        element={
          <ProtectedRoute allowedRole="teacher">
            <TeacherPapersPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/teacher/upload" 
        element={
          <ProtectedRoute allowedRole="teacher">
            <TeacherUploadPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/teacher/class-progress" 
        element={
          <ProtectedRoute allowedRole="teacher">
            <ClassProgressPage />
          </ProtectedRoute>
        } 
      />

      {/* Catch all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
        <Toaster position="top-right" richColors />
      </Router>
    </AuthProvider>
  );
};

export default App;
