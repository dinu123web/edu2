import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { Student, Teacher } from '@/types';
import { StudentDB, TeacherDB, NICDB, SessionDB, initDatabase } from '@/services/database';

interface AuthContextType {
  currentUser: Student | Teacher | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, _password: string, role: 'student' | 'teacher') => Promise<{ success: boolean; message: string }>;
  registerStudent: (data: StudentRegistrationData) => Promise<{ success: boolean; message: string }>;
  registerTeacher: (data: TeacherRegistrationData) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  updateUser: (user: Student | Teacher) => void;
}

interface StudentRegistrationData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  nic: string;
  adminNo: string;
  address: string;
  birthday: string;
}

interface TeacherRegistrationData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  secretCode: string;
  address: string;
  birthday: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<Student | Teacher | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    initDatabase();
    const user = SessionDB.getCurrentUser();
    setCurrentUser(user);
    setIsLoading(false);
  }, []);

  const login = async (email: string, _password: string, role: 'student' | 'teacher'): Promise<{ success: boolean; message: string }> => {
    try {
      if (role === 'student') {
        const student = StudentDB.getByEmail(email);
        if (!student) {
          return { success: false, message: 'Student not found. Please register first.' };
        }
        // In a real app, you'd hash and compare passwords
        // For demo, we'll just check if the user exists
        SessionDB.setCurrentUser(student);
        setCurrentUser(student);
        return { success: true, message: 'Login successful!' };
      } else {
        const teacher = TeacherDB.getByEmail(email);
        if (!teacher) {
          return { success: false, message: 'Teacher not found. Please register first.' };
        }
        SessionDB.setCurrentUser(teacher);
        setCurrentUser(teacher);
        return { success: true, message: 'Login successful!' };
      }
    } catch (error) {
      return { success: false, message: 'An error occurred during login.' };
    }
  };

  const registerStudent = async (data: StudentRegistrationData): Promise<{ success: boolean; message: string }> => {
    try {
      // Check if NIC is already registered
      if (NICDB.isNICRegistered(data.nic)) {
        return { success: false, message: 'This NIC is already registered with another student.' };
      }

      // Check if admin number is already registered
      if (NICDB.isAdminNoRegistered(data.adminNo)) {
        return { success: false, message: 'This Admin Number is already registered.' };
      }

      // Check if email is already registered
      if (StudentDB.getByEmail(data.email)) {
        return { success: false, message: 'This email is already registered.' };
      }

      // Create student
      const student = StudentDB.create({
        name: `${data.firstName} ${data.lastName}`,
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        role: 'student',
        nic: data.nic,
        adminNo: data.adminNo,
        address: data.address,
        birthday: data.birthday,
      });

      // Register NIC
      NICDB.register(data.nic, data.adminNo, student.id);

      // Auto login
      SessionDB.setCurrentUser(student);
      setCurrentUser(student);

      return { success: true, message: 'Registration successful! Welcome to EduExam Portal.' };
    } catch (error) {
      return { success: false, message: 'An error occurred during registration.' };
    }
  };

  const registerTeacher = async (data: TeacherRegistrationData): Promise<{ success: boolean; message: string }> => {
    try {
      // Verify secret code
      if (!TeacherDB.verifySecretCode(data.secretCode)) {
        return { success: false, message: 'Invalid secret code. Please contact administration.' };
      }

      // Check if email is already registered
      if (TeacherDB.getByEmail(data.email)) {
        return { success: false, message: 'This email is already registered.' };
      }

      // Create teacher
      const teacher = TeacherDB.create({
        name: `${data.firstName} ${data.lastName}`,
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        role: 'teacher',
        secretCode: data.secretCode,
        address: data.address,
        birthday: data.birthday,
      });

      // Auto login
      SessionDB.setCurrentUser(teacher);
      setCurrentUser(teacher);

      return { success: true, message: 'Teacher registration successful!' };
    } catch (error) {
      return { success: false, message: 'An error occurred during registration.' };
    }
  };

  const logout = () => {
    SessionDB.logout();
    setCurrentUser(null);
  };

  const updateUser = (user: Student | Teacher) => {
    SessionDB.setCurrentUser(user);
    setCurrentUser(user);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        isLoading,
        login,
        registerStudent,
        registerTeacher,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
