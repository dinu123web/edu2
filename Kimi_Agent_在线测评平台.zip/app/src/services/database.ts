import type { Student, Teacher, ModelPaper, ExamAttempt, ChatMessage, NICRegistry, ClassAverage } from '@/types';

// Database Keys
const DB_KEYS = {
  STUDENTS: 'eduexam_students',
  TEACHERS: 'eduexam_teachers',
  PAPERS: 'eduexam_papers',
  ATTEMPTS: 'eduexam_attempts',
  CHATS: 'eduexam_chats',
  NIC_REGISTRY: 'eduexam_nic_registry',
  CLASS_AVERAGES: 'eduexam_class_averages',
  CURRENT_USER: 'eduexam_current_user',
  TEACHER_CODE: 'eduexam_teacher_code',
};

// Teacher Secret Code (in production, this would be environment variable)
const TEACHER_SECRET_CODE = 'EDU2024TEACHER';

// Initialize Database
export const initDatabase = () => {
  if (!localStorage.getItem(DB_KEYS.TEACHER_CODE)) {
    localStorage.setItem(DB_KEYS.TEACHER_CODE, TEACHER_SECRET_CODE);
  }
  Object.values(DB_KEYS).forEach(key => {
    if (!localStorage.getItem(key)) {
      localStorage.setItem(key, JSON.stringify([]));
    }
  });
};

// Generic CRUD Operations
const getAll = <T>(key: string): T[] => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
};

const save = <T>(key: string, data: T[]): void => {
  localStorage.setItem(key, JSON.stringify(data));
};

const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Student Operations
export const StudentDB = {
  getAll: (): Student[] => getAll<Student>(DB_KEYS.STUDENTS),
  
  getById: (id: string): Student | undefined => {
    const students = getAll<Student>(DB_KEYS.STUDENTS);
    return students.find(s => s.id === id);
  },
  
  getByEmail: (email: string): Student | undefined => {
    const students = getAll<Student>(DB_KEYS.STUDENTS);
    return students.find(s => s.email === email);
  },
  
  getByNIC: (nic: string): Student | undefined => {
    const students = getAll<Student>(DB_KEYS.STUDENTS);
    return students.find(s => s.nic === nic);
  },
  
  getByAdminNo: (adminNo: string): Student | undefined => {
    const students = getAll<Student>(DB_KEYS.STUDENTS);
    return students.find(s => s.adminNo === adminNo);
  },
  
  create: (studentData: Omit<Student, 'id' | 'createdAt' | 'progress' | 'examAttempts'>): Student => {
    const students = getAll<Student>(DB_KEYS.STUDENTS);
    const newStudent: Student = {
      ...studentData,
      id: generateId(),
      createdAt: new Date().toISOString(),
      progress: [],
      examAttempts: [],
    };
    students.push(newStudent);
    save(DB_KEYS.STUDENTS, students);
    return newStudent;
  },
  
  update: (id: string, updates: Partial<Student>): Student | null => {
    const students = getAll<Student>(DB_KEYS.STUDENTS);
    const index = students.findIndex(s => s.id === id);
    if (index === -1) return null;
    students[index] = { ...students[index], ...updates };
    save(DB_KEYS.STUDENTS, students);
    return students[index];
  },
};

// Teacher Operations
export const TeacherDB = {
  getAll: (): Teacher[] => getAll<Teacher>(DB_KEYS.TEACHERS),
  
  getById: (id: string): Teacher | undefined => {
    const teachers = getAll<Teacher>(DB_KEYS.TEACHERS);
    return teachers.find(t => t.id === id);
  },
  
  getByEmail: (email: string): Teacher | undefined => {
    const teachers = getAll<Teacher>(DB_KEYS.TEACHERS);
    return teachers.find(t => t.email === email);
  },
  
  create: (teacherData: Omit<Teacher, 'id' | 'createdAt'>): Teacher => {
    const teachers = getAll<Teacher>(DB_KEYS.TEACHERS);
    const newTeacher: Teacher = {
      ...teacherData,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    teachers.push(newTeacher);
    save(DB_KEYS.TEACHERS, teachers);
    return newTeacher;
  },
  
  verifySecretCode: (code: string): boolean => {
    return code === TEACHER_SECRET_CODE;
  },
};

// NIC Registry Operations
export const NICDB = {
  getAll: (): NICRegistry[] => getAll<NICRegistry>(DB_KEYS.NIC_REGISTRY),
  
  isNICRegistered: (nic: string): boolean => {
    const registry = getAll<NICRegistry>(DB_KEYS.NIC_REGISTRY);
    return registry.some(r => r.nic === nic);
  },
  
  isAdminNoRegistered: (adminNo: string): boolean => {
    const registry = getAll<NICRegistry>(DB_KEYS.NIC_REGISTRY);
    return registry.some(r => r.adminNo === adminNo);
  },
  
  getByNIC: (nic: string): NICRegistry | undefined => {
    const registry = getAll<NICRegistry>(DB_KEYS.NIC_REGISTRY);
    return registry.find(r => r.nic === nic);
  },
  
  register: (nic: string, adminNo: string, studentId: string): NICRegistry => {
    const registry = getAll<NICRegistry>(DB_KEYS.NIC_REGISTRY);
    const entry: NICRegistry = {
      nic,
      adminNo,
      studentId,
      registeredAt: new Date().toISOString(),
    };
    registry.push(entry);
    save(DB_KEYS.NIC_REGISTRY, registry);
    return entry;
  },
};

// Model Paper Operations
export const PaperDB = {
  getAll: (): ModelPaper[] => getAll<ModelPaper>(DB_KEYS.PAPERS),
  
  getActive: (): ModelPaper[] => {
    const papers = getAll<ModelPaper>(DB_KEYS.PAPERS);
    const now = new Date().toISOString();
    return papers.filter(p => p.isActive && p.expiresAt > now);
  },
  
  getById: (id: string): ModelPaper | undefined => {
    const papers = getAll<ModelPaper>(DB_KEYS.PAPERS);
    return papers.find(p => p.id === id);
  },
  
  getByTeacher: (teacherId: string): ModelPaper[] => {
    const papers = getAll<ModelPaper>(DB_KEYS.PAPERS);
    return papers.filter(p => p.teacherId === teacherId);
  },
  
  create: (paperData: Omit<ModelPaper, 'id' | 'createdAt'>): ModelPaper => {
    const papers = getAll<ModelPaper>(DB_KEYS.PAPERS);
    const newPaper: ModelPaper = {
      ...paperData,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    papers.push(newPaper);
    save(DB_KEYS.PAPERS, papers);
    return newPaper;
  },
  
  update: (id: string, updates: Partial<ModelPaper>): ModelPaper | null => {
    const papers = getAll<ModelPaper>(DB_KEYS.PAPERS);
    const index = papers.findIndex(p => p.id === id);
    if (index === -1) return null;
    papers[index] = { ...papers[index], ...updates };
    save(DB_KEYS.PAPERS, papers);
    return papers[index];
  },
  
  delete: (id: string): boolean => {
    const papers = getAll<ModelPaper>(DB_KEYS.PAPERS);
    const filtered = papers.filter(p => p.id !== id);
    if (filtered.length === papers.length) return false;
    save(DB_KEYS.PAPERS, filtered);
    return true;
  },
};

// Exam Attempt Operations
export const AttemptDB = {
  getAll: (): ExamAttempt[] => getAll<ExamAttempt>(DB_KEYS.ATTEMPTS),
  
  getById: (id: string): ExamAttempt | undefined => {
    const attempts = getAll<ExamAttempt>(DB_KEYS.ATTEMPTS);
    return attempts.find(a => a.id === id);
  },
  
  getByStudent: (studentId: string): ExamAttempt[] => {
    const attempts = getAll<ExamAttempt>(DB_KEYS.ATTEMPTS);
    return attempts.filter(a => a.studentId === studentId);
  },
  
  getByPaper: (paperId: string): ExamAttempt[] => {
    const attempts = getAll<ExamAttempt>(DB_KEYS.ATTEMPTS);
    return attempts.filter(a => a.paperId === paperId);
  },
  
  getStudentPaperAttempt: (studentId: string, paperId: string): ExamAttempt | undefined => {
    const attempts = getAll<ExamAttempt>(DB_KEYS.ATTEMPTS);
    return attempts.find(a => a.studentId === studentId && a.paperId === paperId);
  },
  
  create: (attemptData: Omit<ExamAttempt, 'id'>): ExamAttempt => {
    const attempts = getAll<ExamAttempt>(DB_KEYS.ATTEMPTS);
    const newAttempt: ExamAttempt = {
      ...attemptData,
      id: generateId(),
    };
    attempts.push(newAttempt);
    save(DB_KEYS.ATTEMPTS, attempts);
    return newAttempt;
  },
  
  update: (id: string, updates: Partial<ExamAttempt>): ExamAttempt | null => {
    const attempts = getAll<ExamAttempt>(DB_KEYS.ATTEMPTS);
    const index = attempts.findIndex(a => a.id === id);
    if (index === -1) return null;
    attempts[index] = { ...attempts[index], ...updates };
    save(DB_KEYS.ATTEMPTS, attempts);
    return attempts[index];
  },
  
  calculateClassAverage: (paperId: string): ClassAverage => {
    const attempts = getAll<ExamAttempt>(DB_KEYS.ATTEMPTS);
    const paperAttempts = attempts.filter(a => a.paperId === paperId && a.status === 'graded');
    const paper = PaperDB.getById(paperId);
    
    if (paperAttempts.length === 0) {
      return {
        paperId,
        paperTitle: paper?.title || 'Unknown',
        averageMarks: 0,
        totalStudents: 0,
        highestMarks: 0,
        lowestMarks: 0,
        createdAt: new Date().toISOString(),
      };
    }
    
    const marks = paperAttempts.map(a => a.marks || 0);
    return {
      paperId,
      paperTitle: paper?.title || 'Unknown',
      averageMarks: marks.reduce((a, b) => a + b, 0) / marks.length,
      totalStudents: marks.length,
      highestMarks: Math.max(...marks),
      lowestMarks: Math.min(...marks),
      createdAt: new Date().toISOString(),
    };
  },
};

// Class Average Operations
export const ClassAverageDB = {
  getAll: (): ClassAverage[] => getAll<ClassAverage>(DB_KEYS.CLASS_AVERAGES),
  
  getByPaper: (paperId: string): ClassAverage | undefined => {
    const averages = getAll<ClassAverage>(DB_KEYS.CLASS_AVERAGES);
    return averages.find(a => a.paperId === paperId);
  },
  
  save: (average: ClassAverage): void => {
    const averages = getAll<ClassAverage>(DB_KEYS.CLASS_AVERAGES);
    const index = averages.findIndex(a => a.paperId === average.paperId);
    if (index >= 0) {
      averages[index] = average;
    } else {
      averages.push(average);
    }
    save(DB_KEYS.CLASS_AVERAGES, averages);
  },
  
  updateAll: (): ClassAverage[] => {
    const papers = PaperDB.getAll();
    const updated: ClassAverage[] = [];
    papers.forEach(paper => {
      const avg = AttemptDB.calculateClassAverage(paper.id);
      ClassAverageDB.save(avg);
      updated.push(avg);
    });
    return updated;
  },
};

// Chat Operations
export const ChatDB = {
  getAll: (): ChatMessage[] => getAll<ChatMessage>(DB_KEYS.CHATS),
  
  getByStudent: (studentId: string): ChatMessage[] => {
    const chats = getAll<ChatMessage>(DB_KEYS.CHATS);
    return chats.filter(c => c.studentId === studentId);
  },
  
  getByPaper: (paperId: string): ChatMessage[] => {
    const chats = getAll<ChatMessage>(DB_KEYS.CHATS);
    return chats.filter(c => c.paperId === paperId);
  },
  
  create: (chatData: Omit<ChatMessage, 'id' | 'timestamp'>): ChatMessage => {
    const chats = getAll<ChatMessage>(DB_KEYS.CHATS);
    const newChat: ChatMessage = {
      ...chatData,
      id: generateId(),
      timestamp: new Date().toISOString(),
    };
    chats.push(newChat);
    save(DB_KEYS.CHATS, chats);
    return newChat;
  },
};

// Session Operations
export const SessionDB = {
  getCurrentUser: (): Student | Teacher | null => {
    const data = localStorage.getItem(DB_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  },
  
  setCurrentUser: (user: Student | Teacher | null): void => {
    if (user) {
      localStorage.setItem(DB_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(DB_KEYS.CURRENT_USER);
    }
  },
  
  logout: (): void => {
    localStorage.removeItem(DB_KEYS.CURRENT_USER);
  },
};

// Auto-marking System
export const MarkingSystem = {
  calculateMarks: (attempt: ExamAttempt, paper: ModelPaper): { marks: number; percentage: number; grade: string } => {
    let totalMarks = 0;
    const markingScheme = paper.markingScheme;
    
    Object.entries(attempt.answers).forEach(([questionId, answer]) => {
      const scheme = markingScheme[questionId];
      if (scheme) {
        if (Array.isArray(scheme.correctAnswer)) {
          // Multiple correct answers
          if (Array.isArray(answer)) {
            const correct = answer.filter(a => scheme.correctAnswer.includes(a)).length;
            const incorrect = answer.filter(a => !scheme.correctAnswer.includes(a)).length;
            const marks = (correct / (scheme.correctAnswer as string[]).length) * scheme.marks - (incorrect * 0.25);
            totalMarks += Math.max(0, marks);
          } else if (scheme.correctAnswer.includes(answer)) {
            totalMarks += scheme.marks / (scheme.correctAnswer as string[]).length;
          }
        } else {
          // Single correct answer
          if (typeof answer === 'string' && answer.toLowerCase() === (scheme.correctAnswer as string).toLowerCase()) {
            totalMarks += scheme.marks;
          }
        }
      }
    });
    
    const percentage = (totalMarks / paper.totalMarks) * 100;
    let grade = 'F';
    if (percentage >= 90) grade = 'A+';
    else if (percentage >= 80) grade = 'A';
    else if (percentage >= 70) grade = 'B+';
    else if (percentage >= 60) grade = 'B';
    else if (percentage >= 50) grade = 'C';
    else if (percentage >= 40) grade = 'D';
    
    return { marks: Math.round(totalMarks * 100) / 100, percentage: Math.round(percentage * 100) / 100, grade };
  },
};

// Plagiarism Detection (Simple implementation)
export const PlagiarismDetector = {
  check: (content: string, resources: string[]): { score: number; sources: Array<{ url: string; title: string; similarity: number }>; flaggedContent: string[] } => {
    const sources: Array<{ url: string; title: string; similarity: number }> = [];
    const flaggedContent: string[] = [];
    let totalSimilarity = 0;
    
    const sentences = content.toLowerCase().split(/[.!?]+/).filter(s => s.trim().length > 10);
    
    resources.forEach((resource, idx) => {
      const resourceLower = resource.toLowerCase();
      let matches = 0;
      
      sentences.forEach(sentence => {
        if (resourceLower.includes(sentence.trim())) {
          matches++;
          if (!flaggedContent.includes(sentence.trim())) {
            flaggedContent.push(sentence.trim());
          }
        }
      });
      
      const similarity = (matches / sentences.length) * 100;
      if (similarity > 10) {
        sources.push({
          url: `Resource ${idx + 1}`,
          title: `Reference Material ${idx + 1}`,
          similarity: Math.round(similarity * 100) / 100,
        });
        totalSimilarity += similarity;
      }
    });
    
    return {
      score: Math.min(100, Math.round(totalSimilarity * 100) / 100),
      sources,
      flaggedContent,
    };
  },
};

export { DB_KEYS, TEACHER_SECRET_CODE };
