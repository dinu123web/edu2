// User Types
export interface User {
  id: string;
  email: string;
  name: string;
  firstName: string;
  lastName: string;
  address: string;
  birthday: string; // Format: YYYY-MM-DD
  role: 'student' | 'teacher';
  createdAt: string;
}

export interface Student extends User {
  role: 'student';
  nic: string;
  adminNo: string;
  progress: StudentProgress[];
  examAttempts: ExamAttempt[];
}

export interface Teacher extends User {
  role: 'teacher';
  secretCode: string;
}

// Exam/Paper Types
export interface ModelPaper {
  id: string;
  title: string;
  description: string;
  subject: string;
  duration: number; // in minutes
  totalMarks: number;
  questions: Question[];
  answerKey: AnswerKey;
  markingScheme: MarkingScheme;
  teacherId: string;
  createdAt: string;
  expiresAt: string; // one month from creation
  zoomRecording?: string;
  pdfUrl?: string;
  isActive: boolean;
}

export interface Question {
  id: string;
  type: 'mcq' | 'essay' | 'short_answer';
  question: string;
  options?: string[];
  marks: number;
  imageUrl?: string;
}

export interface AnswerKey {
  [questionId: string]: string | string[];
}

export interface MarkingScheme {
  [questionId: string]: {
    correctAnswer: string | string[];
    marks: number;
    partialMarks?: { condition: string; marks: number }[];
    explanation?: string;
  };
}

// Exam Attempt Types
export interface ExamAttempt {
  id: string;
  studentId: string;
  paperId: string;
  startedAt: string;
  submittedAt?: string;
  answers: { [questionId: string]: string | string[] };
  pdfAnswerUrl?: string;
  marks?: number;
  percentage?: number;
  grade?: string;
  status: 'in_progress' | 'submitted' | 'graded';
  timeSpent: number; // in seconds
  plagiarismCheck?: PlagiarismResult;
}

export interface PlagiarismResult {
  score: number; // 0-100
  sources: PlagiarismSource[];
  flaggedContent: string[];
}

export interface PlagiarismSource {
  url: string;
  title: string;
  similarity: number;
}

// Progress Types
export interface StudentProgress {
  paperId: string;
  paperTitle: string;
  marks: number;
  totalMarks: number;
  percentage: number;
  completedAt: string;
  rank?: number;
}

export interface ClassAverage {
  paperId: string;
  paperTitle: string;
  averageMarks: number;
  totalStudents: number;
  highestMarks: number;
  lowestMarks: number;
  createdAt: string;
}

// Chat Types
export interface ChatMessage {
  id: string;
  studentId: string;
  paperId: string;
  message: string;
  response: string;
  timestamp: string;
}

// NIC Registry
export interface NICRegistry {
  nic: string;
  adminNo: string;
  studentId: string;
  registeredAt: string;
}

// App State
export interface AppState {
  currentUser: Student | Teacher | null;
  isAuthenticated: boolean;
  papers: ModelPaper[];
  examAttempts: ExamAttempt[];
  classAverages: ClassAverage[];
  nicRegistry: NICRegistry[];
}
